"""
Conversão entre "valor em USDT desejado" e as unidades nativas de cada mercado.

- Spot: a MEXC aceita quoteOrderQty diretamente (gastar/receber X USDT), então
  não precisamos calcular quantidade manualmente — a própria exchange faz a
  conversão ao preço de execução. Ainda assim, aplicamos os filtros de
  quantidade mínima/passo do símbolo antes de enviar, para não ter a ordem
  rejeitada por regra de lote.

- Futures: não existe "valor em quote" nativo. É preciso calcular `vol`
  (quantidade de CONTRATOS, não de moeda) a partir do valor em USDT desejado:

      vol = valor_usdt / (preco * contractSize)

  arredondado para baixo no múltiplo de contrato mais próximo (nunca para
  cima, para não expor mais capital do que configurado), respeitando minVol.
"""
import math
from dataclasses import dataclass


@dataclass
class ContractSpec:
    symbol: str
    contract_size: float   # valor de 1 contrato, na moeda base (ex: 0.0001 BTC por contrato)
    min_vol: int            # quantidade mínima de contratos por ordem
    vol_scale: int = 0       # casas decimais permitidas em vol (normalmente 0, contratos são inteiros)

    @classmethod
    def from_api_response(cls, data: dict) -> "ContractSpec":
        return cls(
            symbol=data["symbol"],
            contract_size=float(data["contractSize"]),
            min_vol=int(data.get("minVol", 1)),
            vol_scale=int(data.get("volScale", 0)),
        )


def usdt_to_futures_vol(usdt_value: float, price: float, spec: ContractSpec) -> int:
    """
    Calcula quantos contratos comprar/vender para expor aproximadamente
    `usdt_value` USDT de valor nocional, ao preço atual `price`.

    Arredonda para BAIXO (nunca expõe mais do que o configurado). Retorna 0
    se o valor solicitado for menor que 1 contrato — nesse caso o chamador
    deve tratar como "valor insuficiente para este par" e não enviar ordem.
    """
    if price <= 0 or spec.contract_size <= 0:
        return 0

    raw_vol = usdt_value / (price * spec.contract_size)
    step = 10 ** (-spec.vol_scale) if spec.vol_scale > 0 else 1
    vol = math.floor(raw_vol / step) * step

    if spec.vol_scale == 0:
        vol = int(vol)

    if vol < spec.min_vol:
        return 0

    return vol


def futures_vol_to_usdt(vol: float, price: float, spec: ContractSpec) -> float:
    """Valor nocional em USDT de uma posição/ordem de `vol` contratos ao preço `price`."""
    return vol * spec.contract_size * price


@dataclass
class SpotSymbolSpec:
    symbol: str
    base_asset_precision: int
    quote_precision: int
    min_notional: float = 0.0

    @classmethod
    def from_exchange_info(cls, data: dict) -> "SpotSymbolSpec":
        min_notional = 0.0
        for f in data.get("filters", []):
            if f.get("filterType") in ("MIN_NOTIONAL", "NOTIONAL"):
                min_notional = float(f.get("minNotional", f.get("minNotionalValue", 0)) or 0)
        return cls(
            symbol=data["symbol"],
            base_asset_precision=int(data.get("baseAssetPrecision", 8)),
            quote_precision=int(data.get("quotePrecision", 8)),
            min_notional=min_notional,
        )


def validate_spot_quote_qty(usdt_value: float, spec: SpotSymbolSpec) -> bool:
    """Confirma que o valor em USDT respeita o notional mínimo exigido pela MEXC para este par."""
    if spec.min_notional and usdt_value < spec.min_notional:
        return False
    return usdt_value > 0


def round_spot_quantity(qty: float, spec: SpotSymbolSpec) -> float:
    """
    Arredonda uma quantidade do ativo base para o número de casas decimais
    permitido pela MEXC (baseAssetPrecision), sempre para BAIXO - nunca
    arredonda para cima, para não correr o risco de vender mais do que o
    saldo real disponível. Sem isso, a MEXC rejeita a ordem com o erro
    "amount scale is invalid" quando a quantidade tem mais casas decimais
    do que o permitido (o que acontece com frequência, já que o saldo
    consultado via API pode vir com arredondamento de ponto flutuante
    acumulado, ex: 1188.70000001 em vez de 1188.7).
    """
    if qty <= 0:
        return 0.0
    factor = 10 ** spec.base_asset_precision
    return math.floor(qty * factor) / factor


def round_spot_quote_qty(quote_qty: float, spec: SpotSymbolSpec) -> float:
    """
    Arredonda um valor em moeda de cotação (USDT) para o número de casas
    decimais permitido pela MEXC (quotePrecision) ao enviar uma ordem via
    quoteOrderQty. Sempre para BAIXO, pelo mesmo motivo de
    round_spot_quantity: o valor calculado internamente (ex: a partir do
    fill do Futures, via multiplicação de floats) frequentemente vem com
    mais casas decimais do que o permitido, gerando "amount scale is
    invalid" mesmo em ordens de COMPRA por valor (não só em vendas por
    quantidade).
    """
    if quote_qty <= 0:
        return 0.0
    factor = 10 ** spec.quote_precision
    return math.floor(quote_qty * factor) / factor
