"""
Máquina de estados do bot de arbitragem Spot x Futures, por par.

FASE 2: este módulo roda exclusivamente em modo SIMULATION. Não existe,
neste arquivo, nenhum caminho de código capaz de enviar uma ordem real -
os métodos "_execute_entry" e "_execute_exit" apenas logam a decisão e
atualizam o estado interno como se a ordem tivesse sido preenchida ao
preço de mercado no momento da decisão. Isso permite validar a lógica de
entrada/saída, o casamento de valores entre pernas, e o comportamento em
reconexão - sem nenhum risco de capital.

A Fase 3 vai introduzir um ExecutionMode.LIVE que troca essas duas funções
por chamadas reais aos clientes REST (bot/mexc_spot_client.py e
bot/mexc_futures_client.py), sem alterar a máquina de estados em si.

Estados possíveis por par:
    IDLE          - monitorando, sem posição, esperando spread de entrada
    ENTERING      - ordens de entrada "enviadas" (simulado), aguardando fill
    OPEN          - posição aberta nas duas pernas, monitorando spread de saída
    EXITING       - ordens de saída "enviadas" (simulado), aguardando fill total
    PAUSED_ERROR  - pausado automaticamente (erro/discrepância) - nunca abre posição nova
    MANUAL_HALT   - pausado manualmente (kill switch ou toggle do usuário)
"""
import asyncio
import logging
import math
import time
from dataclasses import dataclass
from enum import Enum
from typing import Optional

from bot.bot_storage import BotStorage
from bot.sizing import (
    ContractSpec, usdt_to_futures_vol, futures_vol_to_usdt,
    SpotSymbolSpec, round_spot_quantity, round_spot_quote_qty,
)

logger = logging.getLogger("bot_engine")


class ExecutionMode(Enum):
    SIMULATION = "simulation"
    LIVE = "live"  # não utilizado nesta fase


class PairState(Enum):
    IDLE = "IDLE"
    ENTERING = "ENTERING"
    OPEN = "OPEN"
    EXITING = "EXITING"
    PAUSED_ERROR = "PAUSED_ERROR"
    MANUAL_HALT = "MANUAL_HALT"


@dataclass
class PairConfig:
    symbol: str
    enabled: bool = False
    entry_spread_pct: float = 1.0   # entra quando |spread| >= este valor
    exit_spread_pct: float = 0.2    # sai quando |spread| <= este valor (reverteu boa parte do movimento)
    position_size_usdt: float = 100.0


@dataclass
class PairRuntime:
    """Estado em memória (não persistido diretamente, espelha o bot_storage)."""
    symbol: str
    state: PairState = PairState.IDLE
    entry_spread_pct: Optional[float] = None
    entry_spot_price: Optional[float] = None
    entry_futures_price: Optional[float] = None
    entry_spot_qty: Optional[float] = None
    entry_futures_vol: Optional[float] = None
    entry_notional_usdt: Optional[float] = None
    entry_ts: Optional[float] = None
    last_error: Optional[str] = None

    def to_dict(self) -> dict:
        return {
            "symbol": self.symbol,
            "state": self.state.value,
            "entry_spread_pct": self.entry_spread_pct,
            "entry_spot_price": self.entry_spot_price,
            "entry_futures_price": self.entry_futures_price,
            "entry_spot_qty": self.entry_spot_qty,
            "entry_futures_vol": self.entry_futures_vol,
            "entry_notional_usdt": self.entry_notional_usdt,
            "entry_ts": self.entry_ts,
            "last_error": self.last_error,
        }


class ArbitrageBotEngine:
    """
    Motor do bot. Recebe atualizações de preço (spot_price, futures_price) do
    engine de monitoramento já existente (dashboard/engine.py) via
    `on_price_update`, e decide entradas/saídas por par com base na config.
    """

    def __init__(
        self,
        bot_storage: BotStorage,
        execution_mode: ExecutionMode = ExecutionMode.SIMULATION,
        spot_client=None,
        futures_client=None,
        max_total_exposure_usdt: Optional[float] = None,
    ):
        self.storage = bot_storage
        self.execution_mode = execution_mode
        self.spot_client = spot_client      # bot.mexc_spot_client.MexcSpotClient (obrigatório se LIVE)
        self.futures_client = futures_client  # bot.mexc_futures_client.MexcFuturesClient (obrigatório se LIVE)
        self.max_total_exposure_usdt = max_total_exposure_usdt  # None = sem teto
        self.configs: dict[str, PairConfig] = {}
        self.runtimes: dict[str, PairRuntime] = {}
        self.contract_specs: dict[str, ContractSpec] = {}
        self.spot_specs: dict[str, SpotSymbolSpec] = {}
        self._lock = asyncio.Lock()
        self._subscribers: list[asyncio.Queue] = []
        self.connection_degraded = False  # true = internet caiu / MEXC instável -> pausa novas entradas

        if self.execution_mode == ExecutionMode.LIVE and (spot_client is None or futures_client is None):
            raise RuntimeError(
                "ExecutionMode.LIVE exige spot_client e futures_client configurados. "
                "Sem eles, o motor não tem como enviar ordens reais."
            )

    @staticmethod
    def _normalize_symbol(symbol: str) -> str:
        """
        O dashboard identifica pares pelo "display_symbol" (ex: "JIMOTHY",
        sem sufixo). O bot precisa usar exatamente essa mesma chave para
        casar com os preços recebidos via on_price_update — caso contrário,
        um par configurado como "JIMOTHYUSDT" nunca recebe atualização de
        preço nenhuma (o par fica preso em IDLE mesmo com o spread batendo).
        Aceita símbolos digitados com ou sem "USDT" e sempre normaliza para
        o formato sem sufixo, para nunca depender de quem está chamando
        acertar o formato certo.
        """
        symbol = symbol.strip().upper()
        if symbol.endswith("USDT") and len(symbol) > 4:
            return symbol[:-4]
        return symbol

    # ---------------- Pub/Sub para a interface ----------------

    def subscribe(self) -> asyncio.Queue:
        q = asyncio.Queue(maxsize=100)
        self._subscribers.append(q)
        return q

    def unsubscribe(self, q: asyncio.Queue):
        if q in self._subscribers:
            self._subscribers.remove(q)

    async def _broadcast(self, event: dict):
        for q in list(self._subscribers):
            try:
                q.put_nowait(event)
            except asyncio.QueueFull:
                pass

    async def _broadcast_snapshot(self):
        await self._broadcast({"type": "bot_snapshot", "pairs": self.get_snapshot()})

    # ---------------- Inicialização / configuração ----------------

    async def load_configs(self):
        saved = await self.storage.get_all_pair_configs()
        async with self._lock:
            for raw_symbol, cfg in saved.items():
                symbol = self._normalize_symbol(raw_symbol)
                self.configs[symbol] = PairConfig(symbol=symbol, **cfg)
                if symbol not in self.runtimes:
                    self.runtimes[symbol] = PairRuntime(symbol=symbol)
                if symbol != raw_symbol:
                    # Migração: config foi salva com o sufixo USDT (formato antigo,
                    # de antes da normalização) - regrava com a chave correta para
                    # que volte a casar com os preços recebidos do dashboard.
                    logger.warning(
                        "Migrando config do par '%s' para o formato normalizado '%s'.",
                        raw_symbol, symbol,
                    )
                    await self.storage.upsert_pair_config(
                        symbol, cfg["enabled"], cfg["entry_spread_pct"],
                        cfg["exit_spread_pct"], cfg["position_size_usdt"],
                    )
                    await self.storage.delete_pair_config(raw_symbol)

            saved_positions = await self.storage.get_all_positions()
            for raw_symbol, pos in saved_positions.items():
                symbol = self._normalize_symbol(raw_symbol)
                if symbol not in self.runtimes:
                    self.runtimes[symbol] = PairRuntime(symbol=symbol)
                rt = self.runtimes[symbol]
                rt.state = PairState(pos["state"])
                rt.entry_spread_pct = pos["entry_spread_pct"]
                rt.entry_spot_price = pos["entry_spot_price"]
                rt.entry_futures_price = pos["entry_futures_price"]
                rt.entry_spot_qty = pos["entry_spot_qty"]
                rt.entry_futures_vol = pos["entry_futures_vol"]
                rt.entry_notional_usdt = pos["entry_notional_usdt"]
                rt.entry_ts = pos["entry_ts"]

    async def set_pair_config(self, symbol: str, enabled: bool, entry_spread_pct: float,
                               exit_spread_pct: float, position_size_usdt: float):
        symbol = self._normalize_symbol(symbol)

        if entry_spread_pct <= 0:
            raise ValueError(
                "entry_spread_pct deve ser positivo. A estratégia (compra Spot + "
                "vende Futures) só é lucrativa quando o spread futures-spot é "
                "positivo; a entrada nunca deve ser configurada para spread negativo."
            )
        if entry_spread_pct <= exit_spread_pct:
            raise ValueError(
                "entry_spread_pct deve ser maior que exit_spread_pct "
                "(o bot entra em spreads grandes e sai quando o spread diminui)."
            )
        if position_size_usdt <= 0:
            raise ValueError("position_size_usdt deve ser maior que zero.")

        async with self._lock:
            self.configs[symbol] = PairConfig(
                symbol=symbol, enabled=enabled, entry_spread_pct=entry_spread_pct,
                exit_spread_pct=exit_spread_pct, position_size_usdt=position_size_usdt,
            )
            if symbol not in self.runtimes:
                self.runtimes[symbol] = PairRuntime(symbol=symbol)

        await self.storage.upsert_pair_config(symbol, enabled, entry_spread_pct, exit_spread_pct, position_size_usdt)
        await self._broadcast_snapshot()

    async def remove_pair_config(self, symbol: str):
        symbol = self._normalize_symbol(symbol)
        async with self._lock:
            self.configs.pop(symbol, None)
            self.runtimes.pop(symbol, None)
            self.contract_specs.pop(symbol, None)
        await self.storage.delete_pair_config(symbol)
        await self.storage.clear_position(symbol)
        await self._broadcast_snapshot()

    # ---------------- Reconexão / degradação ----------------

    def set_connection_degraded(self, degraded: bool):
        """
        Chamado pelo orquestrador quando a conexão com a MEXC cai/volta.
        Conforme especificado: ao degradar, pausa NOVAS entradas, mas não
        mexe em posições já abertas (elas continuam sendo monitoradas e
        podem sair normalmente quando o spread de saída for atingido).
        """
        was_degraded = self.connection_degraded
        self.connection_degraded = degraded
        if degraded and not was_degraded:
            logger.warning("Conexão degradada: novas entradas do bot pausadas até normalizar.")
        elif not degraded and was_degraded:
            logger.info("Conexão normalizada: novas entradas do bot liberadas novamente.")

    def get_current_total_exposure_usdt(self) -> float:
        """Soma o notional de entrada de todas as posições atualmente abertas (OPEN/ENTERING/EXITING)."""
        total = 0.0
        for rt in self.runtimes.values():
            if rt.state in (PairState.OPEN, PairState.ENTERING, PairState.EXITING) and rt.entry_notional_usdt:
                total += rt.entry_notional_usdt
        return total

    # ---------------- Núcleo: reação a atualização de preço ----------------

    async def on_price_update(
        self, symbol: str, spot_price: float, futures_price: float, spread_pct: float,
        prices_from_book: bool = True,
        exit_spread_pct: float | None = None,
        spot_bid: float | None = None, futures_ask: float | None = None,
    ):
        """
        Chamado a cada atualização de preço de um par (mesmo dado que já
        alimenta o dashboard). Decide se deve entrar, sair, ou não fazer nada.

        `prices_from_book`: indica se AMBOS os preços (spot e futures) vieram
        do book (ask do spot / bid do futures), que é o preço executável de
        verdade. Quando False, ao menos um dos lados está usando o "último
        preço negociado" - que em pares ilíquidos pode estar muito longe do
        que se consegue executar agora, gerando spreads fictícios. Nesse caso
        o bot NÃO abre posição nova (mas continua podendo sair de posições já
        abertas, que é sempre a ação mais segura).
        """
        symbol = self._normalize_symbol(symbol)
        cfg = self.configs.get(symbol)
        if cfg is None or not cfg.enabled:
            return

        rt = self.runtimes.get(symbol)
        if rt is None:
            rt = PairRuntime(symbol=symbol)
            self.runtimes[symbol] = rt

        if rt.state in (PairState.PAUSED_ERROR, PairState.MANUAL_HALT):
            return  # nunca age nesses estados

        if rt.state == PairState.IDLE:
            if self.connection_degraded:
                return  # não abre posição nova com conexão degradada

            if not prices_from_book:
                # Preço não-executável (último negociado em vez de book).
                # Logar em nível INFO seria ruidoso demais (acontece a cada
                # update de um par ilíquido), então só registra quando o
                # spread teria sido suficiente para entrar - que é quando a
                # trava realmente evitou uma operação ruim.
                if spread_pct >= cfg.entry_spread_pct:
                    logger.warning(
                        "Entrada em %s BLOQUEADA: spread de %.2f%% atingiria o nível de entrada, mas os "
                        "preços não vieram do book (usando último negociado). Spread pode ser fictício - "
                        "aguardando preço executável.",
                        symbol, spread_pct,
                    )
                return

            # A estratégia é: compra Spot + vende Futures. Isso só trava lucro
            # na convergência quando Futures > Spot (spread positivo). Com
            # spread negativo, esta mesma operação trava PREJUÍZO garantido
            # na convergência (compraria caro no spot, venderia barato no
            # futures) - por isso a entrada exige spread positivo, não |spread|.
            if spread_pct >= cfg.entry_spread_pct:
                if self.max_total_exposure_usdt is not None:
                    current_exposure = self.get_current_total_exposure_usdt()
                    if current_exposure + cfg.position_size_usdt > self.max_total_exposure_usdt:
                        logger.info(
                            "Entrada em %s bloqueada: exposição atual (%.2f USDT) + nova posição "
                            "(%.2f USDT) excederia o teto global de %.2f USDT.",
                            symbol, current_exposure, cfg.position_size_usdt, self.max_total_exposure_usdt,
                        )
                        return
                await self._execute_entry(cfg, rt, spot_price, futures_price, spread_pct)

        elif rt.state == PairState.OPEN:
            # A saída executa nos lados OPOSTOS do book em relação à entrada
            # (vende Spot no bid, recompra Futures no ask), então SÓ pode ser
            # decidida com o spread de saída e os preços do lado correto.
            #
            # Sem esses dados (book indisponível), o bot NÃO sai. O fallback
            # anterior - usar o spread de entrada - causava saídas em
            # condições muito piores do que o bot enxergava: um caso real
            # registrou "tela 0,11%" (entrada) quando o spread de saída real
            # era 2,05%, gerando prejuízo.
            #
            # Ficar na posição esperando dados confiáveis é mais seguro do
            # que sair às cegas com a régua errada.
            if exit_spread_pct is None or spot_bid is None or futures_ask is None:
                logger.debug(
                    "Saída de %s adiada: dados de saída incompletos "
                    "(exit_spread=%s, spot_bid=%s, futures_ask=%s).",
                    symbol, exit_spread_pct, spot_bid, futures_ask,
                )
                return

            if not prices_from_book:
                # Mesma exigência da entrada: preço fora do book é
                # "último negociado", que não representa o executável.
                if exit_spread_pct <= cfg.exit_spread_pct:
                    logger.warning(
                        "Saída de %s BLOQUEADA: spread de saída de %.2f%% atingiria o nível, mas os "
                        "preços não vieram do book. Aguardando preço executável.",
                        symbol, exit_spread_pct,
                    )
                return

            if exit_spread_pct <= cfg.exit_spread_pct:
                # Preços do lado correto do book: vende Spot no bid,
                # recompra Futures no ask.
                await self._execute_exit(cfg, rt, spot_bid, futures_ask, exit_spread_pct)

        # ENTERING e EXITING nesta fase são transitórios instantâneos (simulação
        # não tem latência de fill real) - na prática o estado nunca "para" neles
        # por mais que o tempo de uma chamada. A Fase 3 vai expandir esses estados
        # para aguardar fills assíncronos de verdade.

    # ---------------- Entrada ----------------

    async def _execute_entry(self, cfg: PairConfig, rt: PairRuntime, spot_price: float, futures_price: float, spread_pct: float):
        rt.state = PairState.ENTERING
        await self._broadcast_snapshot()

        if self.execution_mode == ExecutionMode.SIMULATION:
            await self._execute_entry_simulated(cfg, rt, spot_price, futures_price, spread_pct)
        else:
            await self._execute_entry_live(cfg, rt, spot_price, futures_price, spread_pct)

    async def _execute_entry_simulated(self, cfg: PairConfig, rt: PairRuntime, spot_price: float, futures_price: float, spread_pct: float):
        # Sem contract_specs carregado, assumimos contractSize=1 para fins de
        # simulação proporcional - o valor notional ainda é reportado correto.
        spec = self.contract_specs.get(cfg.symbol)
        notional_usdt = cfg.position_size_usdt

        if spec:
            vol = usdt_to_futures_vol(notional_usdt, futures_price, spec)
            if vol == 0:
                rt.state = PairState.PAUSED_ERROR
                rt.last_error = f"position_size_usdt ({notional_usdt}) é pequeno demais para 1 contrato deste par."
                await self.storage.log_event(cfg.symbol, "entry_failed_size_too_small", {
                    "position_size_usdt": notional_usdt, "futures_price": futures_price,
                }, simulated=True)
                await self._broadcast_snapshot()
                return
            real_notional = futures_vol_to_usdt(vol, futures_price, spec)
        else:
            vol = None
            real_notional = notional_usdt

        spot_qty = real_notional / spot_price if spot_price > 0 else 0

        rt.entry_spread_pct = spread_pct
        rt.entry_spot_price = spot_price
        rt.entry_futures_price = futures_price
        rt.entry_spot_qty = spot_qty
        rt.entry_futures_vol = vol
        rt.entry_notional_usdt = real_notional
        rt.entry_ts = time.time()
        rt.state = PairState.OPEN
        rt.last_error = None

        await self.storage.upsert_position(
            cfg.symbol, PairState.OPEN.value, simulated=True,
            entry_spread_pct=spread_pct, entry_spot_price=spot_price,
            entry_futures_price=futures_price, entry_spot_qty=spot_qty,
            entry_futures_vol=vol, entry_notional_usdt=real_notional, entry_ts=rt.entry_ts,
        )
        await self.storage.log_event(cfg.symbol, "entry_simulated", {
            "spread_pct": spread_pct, "spot_price": spot_price, "futures_price": futures_price,
            "spot_qty": spot_qty, "futures_vol": vol, "notional_usdt": real_notional,
        }, simulated=True)

        logger.info(
            "[SIMULAÇÃO] Entrada em %s: spread=%.2f%% spot_price=%.6f futures_price=%.6f notional=%.2f USDT",
            cfg.symbol, spread_pct, spot_price, futures_price, real_notional,
        )
        await self._broadcast_snapshot()

    async def _execute_entry_live(self, cfg: PairConfig, rt: PairRuntime, spot_price: float, futures_price: float, spread_pct: float):
        """
        Execução real. Estratégia de duas pernas:

        1. Perna ÂNCORA (Futures, SIDE_OPEN_SHORT, a mercado): define o valor
           notional REAL executado, já que o fill pode divergir levemente do
           preço de referência usado para calcular `vol`.
        2. Perna ESPELHO (Spot, BUY, a mercado via quoteOrderQty): gasta
           exatamente o valor notional real da perna âncora, casando os dois
           lados pelo mesmo valor em USDT.
        3. Se a perna espelho falhar por qualquer motivo (rede, saldo, etc),
           a perna âncora já executada é revertida IMEDIATAMENTE com uma
           ordem a mercado contrária, para nunca ficar com exposição
           direcional não intencional.
        """
        futures_symbol = f"{cfg.symbol}_USDT"
        spot_symbol = f"{cfg.symbol}USDT"

        spec = self.contract_specs.get(cfg.symbol)
        if spec is None:
            rt.state = PairState.PAUSED_ERROR
            rt.last_error = "Metadados do contrato futures não carregados para este par. Não é seguro operar sem eles."
            await self.storage.log_event(cfg.symbol, "entry_failed_no_contract_spec", {}, simulated=False)
            await self._broadcast_snapshot()
            return

        vol = usdt_to_futures_vol(cfg.position_size_usdt, futures_price, spec)
        if vol == 0:
            rt.state = PairState.PAUSED_ERROR
            rt.last_error = f"position_size_usdt ({cfg.position_size_usdt}) é pequeno demais para 1 contrato deste par."
            await self.storage.log_event(cfg.symbol, "entry_failed_size_too_small", {
                "position_size_usdt": cfg.position_size_usdt, "futures_price": futures_price,
            }, simulated=False)
            await self._broadcast_snapshot()
            return

        # --- Perna âncora: Futures a mercado (abrir short) ---
        try:
            futures_order = await self.futures_client.submit_order(
                symbol=futures_symbol,
                side=3,  # SIDE_OPEN_SHORT
                vol=vol,
                order_type=5,  # ORDER_TYPE_MARKET
                price=futures_price,  # preço de referência exigido pelo payload mesmo em ordem a mercado
                leverage=1,
                open_type=1,  # OPEN_TYPE_ISOLATED
            )
        except Exception as e:
            rt.state = PairState.PAUSED_ERROR
            rt.last_error = f"Falha ao abrir perna Futures: {e}"
            await self.storage.log_event(cfg.symbol, "entry_failed_futures_order", {"error": str(e)}, simulated=False)
            logger.error("[LIVE] Falha ao abrir perna Futures em %s: %s", cfg.symbol, e)
            await self._broadcast_snapshot()
            return

        # Confirma o fill real da perna âncora antes de prosseguir
        fill = await self._wait_futures_fill(futures_order, futures_symbol, vol)
        if fill is None:
            rt.state = PairState.PAUSED_ERROR
            rt.last_error = (
                "Ordem Futures enviada mas não foi possível confirmar o fill a tempo. "
                "VERIFIQUE MANUALMENTE sua conta MEXC - pode haver uma posição aberta "
                "sem a perna Spot correspondente."
            )
            await self.storage.log_event(cfg.symbol, "entry_fill_unconfirmed", {
                "futures_order": futures_order,
            }, simulated=False)
            logger.error(
                "[LIVE] Fill da perna Futures não confirmado em %s. AÇÃO MANUAL NECESSÁRIA.", cfg.symbol
            )
            await self._broadcast_snapshot()
            return

        real_notional = futures_vol_to_usdt(fill["filled_vol"], fill["avg_price"], spec)

        # Arredonda o valor de cotação (USDT) na precisão exigida pela MEXC
        # para este símbolo, sempre para BAIXO. O valor calculado acima (uma
        # multiplicação de floats a partir do fill do Futures) frequentemente
        # vem com mais casas decimais do que o permitido (ex: 9.31694500000001
        # em vez de 9.32), o que a MEXC rejeita com "amount scale is invalid"
        # mesmo em ordens de COMPRA por valor via quoteOrderQty - o mesmo
        # problema já visto e corrigido do lado da quantidade de venda.
        spot_spec = self.spot_specs.get(cfg.symbol)
        if spot_spec:
            real_notional = round_spot_quote_qty(real_notional, spot_spec)
        else:
            # Sem spec carregada, arredonda para 2 casas decimais como rede de
            # segurança conservadora - USDT quase sempre aceita pelo menos isso.
            real_notional = math.floor(real_notional * 100) / 100

        if real_notional <= 0:
            rt.state = PairState.PAUSED_ERROR
            rt.last_error = "Valor calculado para a perna Spot ficou zerado após arredondamento de precisão."
            await self._revert_futures_leg(cfg.symbol, futures_symbol, fill["filled_vol"], spec, reason="notional_zero_after_rounding")
            await self.storage.log_event(cfg.symbol, "entry_failed_notional_zero", {}, simulated=False)
            await self._broadcast_snapshot()
            return

        # --- Perna espelho: Spot a mercado, casado pelo valor REAL executado no futures ---
        try:
            spot_order = await self.spot_client.new_order_market_by_quote(
                symbol=spot_symbol, side="BUY", quote_order_qty=real_notional,
            )
        except Exception as e:
            logger.error(
                "[LIVE] Perna Spot falhou em %s após Futures já executado. Revertendo Futures IMEDIATAMENTE: %s",
                cfg.symbol, e,
            )
            await self._revert_futures_leg(cfg.symbol, futures_symbol, fill["filled_vol"], spec, reason=str(e))
            rt.state = PairState.PAUSED_ERROR
            rt.last_error = f"Perna Spot falhou ({e}). Perna Futures foi revertida automaticamente a mercado."
            await self.storage.log_event(cfg.symbol, "entry_failed_spot_order_reverted", {
                "error": str(e), "futures_vol_reverted": fill["filled_vol"],
            }, simulated=False)
            await self._broadcast_snapshot()
            return

        # A resposta imediata do POST pode não refletir o preenchimento real
        # ainda (executedQty=0 mesmo a ordem tendo sido aceita), especialmente
        # em mercados menos líquidos. Confirma via polling do status real,
        # em vez de confiar cegamente no campo da resposta imediata - foi
        # exatamente essa confiança cega que causou entradas "fantasma" (o
        # bot achava que tinha comprado Spot, mas na prática o fill não foi
        # confirmado, e a posição ficava com entry_spot_qty=0 silenciosamente).
        spot_qty = float(spot_order.get("executedQty", 0) or 0)
        spot_quote_qty = float(spot_order.get("cummulativeQuoteQty", 0) or 0)

        if spot_qty <= 0:
            spot_order_id = spot_order.get("orderId")
            spot_fill = await self._wait_spot_fill(spot_symbol, spot_order_id, timeout_s=10.0)
            if spot_fill:
                spot_qty = spot_fill["executed_qty"]
                spot_quote_qty = spot_fill["quote_qty"]

        if spot_qty <= 0:
            # Não conseguimos confirmar NENHUM fill da perna Spot. Reverte a
            # perna Futures imediatamente - o mesmo tratamento que já existe
            # para quando a ordem Spot lança exceção, porque o resultado
            # prático é o mesmo: ficamos só com o Futures aberto.
            logger.error(
                "[LIVE] Ordem Spot em %s foi aceita mas o fill não pôde ser confirmado (executedQty=0). "
                "Revertendo Futures IMEDIATAMENTE.", cfg.symbol,
            )
            await self._revert_futures_leg(cfg.symbol, futures_symbol, fill["filled_vol"], spec, reason="spot_fill_unconfirmed")
            rt.state = PairState.PAUSED_ERROR
            rt.last_error = (
                "Ordem Spot foi aceita mas o preenchimento não pôde ser confirmado. "
                "Perna Futures foi revertida automaticamente a mercado. VERIFIQUE MANUALMENTE "
                "sua conta MEXC - pode haver saldo Spot comprado que o bot não contabilizou."
            )
            await self.storage.log_event(cfg.symbol, "entry_failed_spot_fill_unconfirmed", {
                "futures_vol_reverted": fill["filled_vol"], "spot_order": spot_order,
            }, simulated=False)
            await self._broadcast_snapshot()
            return

        spot_fill_price = spot_quote_qty / spot_qty if spot_qty > 0 and spot_quote_qty > 0 else real_notional / spot_qty

        rt.entry_spread_pct = spread_pct
        rt.entry_spot_price = spot_fill_price
        rt.entry_futures_price = fill["avg_price"]
        rt.entry_spot_qty = spot_qty
        rt.entry_futures_vol = fill["filled_vol"]
        rt.entry_notional_usdt = real_notional
        rt.entry_ts = time.time()
        rt.state = PairState.OPEN
        rt.last_error = None

        await self.storage.upsert_position(
            cfg.symbol, PairState.OPEN.value, simulated=False,
            entry_spread_pct=spread_pct, entry_spot_price=spot_fill_price,
            entry_futures_price=fill["avg_price"], entry_spot_qty=spot_qty,
            entry_futures_vol=fill["filled_vol"], entry_notional_usdt=real_notional, entry_ts=rt.entry_ts,
        )
        # Spread REALIZADO da entrada: calculado a partir dos preços de fill
        # reais (o que efetivamente foi pago no spot e recebido no futures),
        # não do "spread de tela" que disparou a decisão. É esse o spread que
        # realmente foi travado na operação.
        entry_spread_realized = None
        if spot_fill_price and spot_fill_price > 0:
            entry_spread_realized = (fill["avg_price"] - spot_fill_price) / spot_fill_price * 100

        await self.storage.log_event(cfg.symbol, "entry_live", {
            # Spread realizado (dos fills) - é o que a interface mostra
            "spread_pct": entry_spread_realized,
            # Spread que estava na tela no momento da decisão, para comparação
            "spread_signal_pct": spread_pct,
            "spot_price": spot_fill_price, "futures_price": fill["avg_price"],
            "spot_fill_price": spot_fill_price, "futures_fill_price": fill["avg_price"],
            "spot_qty": spot_qty, "futures_vol": fill["filled_vol"], "notional_usdt": real_notional,
        }, simulated=False)

        logger.info(
            "[LIVE] Entrada REAL em %s: spread_realizado=%.2f%% (tela=%.2f%%) "
            "spot_fill=%.6f futures_fill=%.6f notional=%.2f USDT",
            cfg.symbol, entry_spread_realized if entry_spread_realized is not None else 0,
            spread_pct, spot_fill_price, fill["avg_price"], real_notional,
        )
        await self._broadcast_snapshot()

    async def _wait_futures_fill(self, order_response: dict, futures_symbol: str, expected_vol: float, timeout_s: float = 15.0) -> Optional[dict]:
        """
        Confirma o fill de uma ordem de futures via polling REST no status da
        ordem (mais simples e robusto do que depender só do WS privado, que
        pode estar temporariamente desconectado). Retorna None se não
        confirmar dentro do timeout - isso é tratado como situação de risco
        que exige intervenção manual, nunca como "assume que deu certo".
        """
        order_id = order_response.get("data")
        if not order_id:
            return None

        deadline = time.time() + timeout_s
        while time.time() < deadline:
            try:
                status = await self.futures_client.get_order(str(order_id))
                data = status.get("data", {})
                state = data.get("state")
                # state 3 = concluída (confirmado em exemplos reais da API)
                if state == 3:
                    filled_vol = float(data.get("dealVol", 0) or 0)
                    deal_avg_price = float(data.get("dealAvgPrice", 0) or 0)
                    if filled_vol > 0 and deal_avg_price > 0:
                        return {"filled_vol": filled_vol, "avg_price": deal_avg_price}
            except Exception as e:
                logger.warning("Erro ao consultar status da ordem futures %s: %s", order_id, e)
            await asyncio.sleep(1.0)

        return None

    async def _wait_spot_fill(self, symbol: str, order_id, timeout_s: float = 10.0) -> Optional[dict]:
        """
        Confirma o fill de uma ordem de Spot via polling REST no status da
        ordem, em vez de confiar apenas na resposta imediata do POST /order
        (que pode retornar antes do preenchimento estar refletido em
        executedQty, especialmente em mercados menos líquidos). Retorna
        None se não confirmar dentro do timeout - tratado como situação de
        risco que exige intervenção manual, nunca como "assume que deu certo".
        """
        if not order_id:
            return None

        deadline = time.time() + timeout_s
        while time.time() < deadline:
            try:
                status = await self.spot_client.get_order(symbol, str(order_id))
                state = status.get("status")
                executed_qty = float(status.get("executedQty", 0) or 0)
                quote_qty = float(status.get("cummulativeQuoteQty", 0) or 0)
                if state == "FILLED" and executed_qty > 0:
                    return {"executed_qty": executed_qty, "quote_qty": quote_qty}
                if state in ("CANCELED", "REJECTED", "EXPIRED"):
                    logger.error(
                        "Ordem Spot %s em %s terminou com status %s antes de preencher.",
                        order_id, symbol, state,
                    )
                    return None
            except Exception as e:
                logger.warning("Erro ao consultar status da ordem Spot %s: %s", order_id, e)
            await asyncio.sleep(0.5)

        return None

    async def _revert_futures_leg(self, symbol: str, futures_symbol: str, vol: float, spec: ContractSpec, reason: str):
        """Fecha a mercado uma posição de futures aberta indevidamente (perna órfã)."""
        try:
            await self.futures_client.submit_order(
                symbol=futures_symbol,
                side=2,  # SIDE_CLOSE_SHORT (reverte um short aberto com side=3)
                vol=vol,
                order_type=5,  # mercado
                price=None,
                leverage=1,
                open_type=1,
                reduce_only=True,
            )
            logger.warning("[LIVE] Perna Futures revertida com sucesso em %s (motivo: %s).", symbol, reason)
        except Exception as e:
            logger.critical(
                "[LIVE] FALHA CRÍTICA: não foi possível reverter a perna Futures em %s após erro na "
                "perna Spot. INTERVENÇÃO MANUAL URGENTE NECESSÁRIA na conta MEXC. Erro: %s", symbol, e,
            )

    # ---------------- Saída ----------------

    async def _execute_exit(self, cfg: PairConfig, rt: PairRuntime, spot_price: float, futures_price: float, spread_pct: float):
        rt.state = PairState.EXITING
        await self._broadcast_snapshot()

        if self.execution_mode == ExecutionMode.SIMULATION:
            await self._execute_exit_simulated(cfg, rt, spot_price, futures_price, spread_pct)
        else:
            await self._execute_exit_live(cfg, rt, spot_price, futures_price, spread_pct)

    async def _execute_exit_simulated(self, cfg: PairConfig, rt: PairRuntime, spot_price: float, futures_price: float, spread_pct: float):
        pnl_spot = None
        pnl_futures = None
        if rt.entry_spot_price and rt.entry_spot_qty:
            pnl_spot = (spot_price - rt.entry_spot_price) * rt.entry_spot_qty
        if rt.entry_futures_price and rt.entry_futures_vol and cfg.symbol in self.contract_specs:
            spec = self.contract_specs[cfg.symbol]
            # short: lucro quando o preço CAI
            pnl_futures = (rt.entry_futures_price - futures_price) * rt.entry_futures_vol * spec.contract_size
        elif rt.entry_futures_price and rt.entry_notional_usdt:
            # sem spec de contrato carregado ainda: aproxima pela variação percentual do notional
            pct_change = (rt.entry_futures_price - futures_price) / rt.entry_futures_price
            pnl_futures = rt.entry_notional_usdt * pct_change

        total_pnl = (pnl_spot or 0) + (pnl_futures or 0)

        await self.storage.log_event(cfg.symbol, "exit_simulated", {
            "exit_spread_pct": spread_pct, "exit_spot_price": spot_price, "exit_futures_price": futures_price,
            "entry_spread_pct": rt.entry_spread_pct, "pnl_spot_usdt": pnl_spot, "pnl_futures_usdt": pnl_futures,
            "pnl_total_usdt": total_pnl,
        }, simulated=True)

        logger.info(
            "[SIMULAÇÃO] Saída em %s: spread=%.2f%% pnl_total=%.4f USDT (spot=%.4f, futures=%.4f)",
            cfg.symbol, spread_pct, total_pnl, pnl_spot or 0, pnl_futures or 0,
        )

        self._clear_runtime_position(rt)
        await self.storage.clear_position(cfg.symbol)
        await self._broadcast_snapshot()

    async def _execute_exit_live(self, cfg: PairConfig, rt: PairRuntime, spot_price: float, futures_price: float, spread_pct: float):
        """
        Fecha as duas pernas A MERCADO, disparadas EM PARALELO (não uma
        depois da outra). Prioriza velocidade sobre preço: como o spread
        pode reverter rápido, minimizar o tempo total de exposição durante
        a saída é mais importante que tentar economizar alguns centavos com
        ordem limite.

        Se a perna Spot falhar (ex: erro de precisão/"amount scale",
        insufficient position residual, etc.), o bot faz UMA nova tentativa
        imediata antes de desistir - a maioria das falhas de precisão se
        resolve sozinha na segunda tentativa, já que o saldo é re-consultado
        e re-arredondado do zero. Se mesmo assim falhar, o par é pausado em
        PAUSED_ERROR (visível na aba Bot) em vez de a operação ser
        silenciosamente registrada como concluída com PnL incompleto.
        """
        futures_symbol = f"{cfg.symbol}_USDT"
        spot_symbol = f"{cfg.symbol}USDT"
        spec = self.contract_specs.get(cfg.symbol)

        # As duas pernas são fechadas SIMULTANEAMENTE (asyncio.gather), não
        # em sequência - isso corta pela metade o tempo total de exposição
        # durante a saída comparado ao fluxo anterior.
        futures_result, spot_result = await asyncio.gather(
            self._close_futures_market(futures_symbol, rt.entry_futures_vol, futures_price, spec),
            self._close_spot_market(spot_symbol, rt.entry_spot_qty, spot_price, symbol_display=cfg.symbol),
            return_exceptions=True,
        )

        if isinstance(futures_result, Exception):
            logger.critical("[LIVE] Falha ao fechar perna Futures em %s: %s", cfg.symbol, futures_result)
            futures_closed_vol, futures_avg_price = 0.0, futures_price
        else:
            futures_closed_vol, futures_avg_price = futures_result

        if isinstance(spot_result, Exception):
            logger.warning(
                "[LIVE] Primeira tentativa de fechar perna Spot em %s falhou (%s). Tentando novamente...",
                cfg.symbol, spot_result,
            )
            try:
                # Segunda tentativa: reconsulta saldo e reaplica arredondamento
                # do zero - resolve a maioria dos casos de "amount scale
                # invalid" causados por um valor de saldo momentaneamente
                # impreciso na primeira consulta.
                spot_closed_qty, spot_avg_price = await self._close_spot_market(
                    spot_symbol, rt.entry_spot_qty, spot_price, symbol_display=cfg.symbol,
                )
                spot_result = None  # sucesso na segunda tentativa
            except Exception as e2:
                spot_result = e2  # falhou de novo - mantém o erro para o check abaixo
                spot_closed_qty, spot_avg_price = 0.0, spot_price
        else:
            spot_closed_qty, spot_avg_price = spot_result
            spot_result = None  # sucesso já na primeira tentativa

        pnl_spot = (spot_avg_price - rt.entry_spot_price) * spot_closed_qty if rt.entry_spot_price else None
        pnl_futures = None
        if spec and rt.entry_futures_price:
            pnl_futures = (rt.entry_futures_price - futures_avg_price) * futures_closed_vol * spec.contract_size
        total_pnl = (pnl_spot or 0) + (pnl_futures or 0)

        if spot_result is not None or spot_closed_qty <= 0:
            # A perna Spot não foi confirmada como vendida, mesmo após retry.
            # NÃO tratamos isso como saída concluída - pausamos o par com
            # aviso explícito, para você poder verificar e vender
            # manualmente o saldo residual na MEXC se necessário.
            rt.state = PairState.PAUSED_ERROR
            rt.last_error = (
                f"Futures foi fechado (pnl_futures={pnl_futures:.4f} USDT), mas a perna Spot NÃO foi "
                f"vendida ({spot_result if spot_result else 'quantidade zerada após arredondamento'}). "
                "VERIFIQUE MANUALMENTE sua conta MEXC - provavelmente há saldo do ativo parado na "
                "carteira Spot que precisa ser vendido manualmente."
            )
            await self.storage.log_event(cfg.symbol, "exit_spot_leg_failed", {
                "exit_spread_pct": spread_pct, "exit_futures_price": futures_avg_price,
                "pnl_futures_usdt": pnl_futures, "spot_error": str(spot_result) if spot_result else "qty_zero_after_rounding",
                "entry_spot_qty": rt.entry_spot_qty,
            }, simulated=False)
            logger.critical(
                "[LIVE] Saída em %s: Futures fechado, mas Spot FALHOU mesmo após retry. "
                "Par pausado para verificação manual. pnl_futures=%.4f USDT",
                cfg.symbol, pnl_futures or 0,
            )
            # Mantém os dados de entrada no runtime (não limpa) para você
            # ainda ter a referência de quanto foi comprado, ao verificar
            # manualmente na MEXC.
            await self._broadcast_snapshot()
            return

        # Spread REALIZADO da saída: calculado a partir dos preços que de
        # fato executaram, não do "spread de tela" que disparou a decisão.
        # Esses dois divergem (às vezes muito, em pares ilíquidos) por causa
        # do slippage das ordens a mercado, e é o realizado que explica o
        # PnL de verdade.
        exit_spread_realized = None
        if spot_avg_price and spot_avg_price > 0 and futures_avg_price:
            exit_spread_realized = (futures_avg_price - spot_avg_price) / spot_avg_price * 100

        await self.storage.log_event(cfg.symbol, "exit_live", {
            # Spread realizado (dos fills) - é o que a interface mostra
            "exit_spread_pct": exit_spread_realized,
            # Spread que estava na tela no momento da decisão, para comparação
            "exit_spread_signal_pct": spread_pct,
            "exit_spot_price": spot_avg_price, "exit_futures_price": futures_avg_price,
            "entry_spread_pct": rt.entry_spread_pct, "pnl_spot_usdt": pnl_spot, "pnl_futures_usdt": pnl_futures,
            "pnl_total_usdt": total_pnl,
        }, simulated=False)

        logger.info(
            "[LIVE] Saída REAL (a mercado, paralela) em %s: spread_realizado=%.2f%% "
            "(tela=%.2f%%) pnl_total=%.4f USDT (spot=%.4f, futures=%.4f)",
            cfg.symbol, exit_spread_realized if exit_spread_realized is not None else 0,
            spread_pct, total_pnl, pnl_spot or 0, pnl_futures or 0,
        )

        self._clear_runtime_position(rt)
        await self.storage.clear_position(cfg.symbol)
        await self._broadcast_snapshot()

    async def _close_futures_market(
        self, futures_symbol: str, vol: float, reference_price: float, spec: Optional[ContractSpec],
    ) -> tuple[float, float]:
        """
        Fecha a posição de Futures com UMA ÚNICA ordem a mercado (reduce_only).
        Sem retry de limite - velocidade é prioridade na saída.
        """
        if not vol or vol <= 0:
            return 0.0, reference_price

        try:
            order = await self.futures_client.submit_order(
                symbol=futures_symbol, side=2, vol=vol, order_type=5,
                price=reference_price, leverage=1, open_type=1, reduce_only=True,
            )
        except Exception as e:
            logger.critical(
                "[LIVE] FALHA CRÍTICA: ordem a mercado de fechamento Futures falhou em %s. "
                "INTERVENÇÃO MANUAL URGENTE. Erro: %s", futures_symbol, e,
            )
            return 0.0, reference_price

        fill = await self._wait_futures_fill(order, futures_symbol, vol, timeout_s=10.0)
        if fill:
            return fill["filled_vol"], fill["avg_price"]

        logger.critical(
            "[LIVE] FALHA CRÍTICA: ordem a mercado de fechamento Futures em %s foi enviada mas o fill "
            "não pôde ser confirmado a tempo. VERIFIQUE MANUALMENTE sua conta MEXC.", futures_symbol,
        )
        return 0.0, reference_price

    async def _close_spot_market(
        self, spot_symbol: str, qty: float, reference_price: float, symbol_display: str = "",
    ) -> tuple[float, float]:
        """
        Vende a posição Spot com UMA ÚNICA ordem a mercado.

        Duas proteções importantes:
        1. Consulta o saldo real disponível antes de vender (a MEXC desconta
           taxa de trading na própria moeda comprada, então a quantidade
           líquida disponível é sempre um pouco menor que a calculada na
           entrada) para nunca tentar vender mais do que existe e disparar
           "Insufficient position".
        2. Arredonda a quantidade para a precisão decimal exigida pela MEXC
           para este símbolo (spot_specs), sempre para BAIXO. Sem isso, a
           MEXC rejeita a ordem com "amount scale is invalid" quando o saldo
           consultado vem com mais casas decimais do que o permitido (comum
           por arredondamento de ponto flutuante).

        Se a venda falhar de qualquer forma, propaga a exceção para o
        chamador em vez de engolir o erro e retornar "vendeu 0" - isso
        garante que o par seja pausado com PAUSED_ERROR visível, em vez de
        a operação parecer ter fechado normalmente com o PnL incompleto.
        """
        if not qty or qty <= 0:
            return 0.0, reference_price

        base_asset = spot_symbol.replace("USDT", "")
        try:
            balance = await self.spot_client.get_balance(base_asset)
            sell_qty = min(qty, balance["free"])
        except Exception as e:
            logger.warning(
                "Não foi possível consultar saldo de %s antes de vender a mercado: %s. "
                "Prosseguindo com a quantidade calculada internamente.", base_asset, e,
            )
            sell_qty = qty

        spec = self.spot_specs.get(symbol_display or base_asset)
        if spec:
            sell_qty = round_spot_quantity(sell_qty, spec)
        else:
            # Sem spec carregada, usa um arredondamento conservador de 6 casas
            # decimais como rede de segurança - reduz bastante o risco de
            # "amount scale is invalid" mesmo sem conhecer a precisão exata.
            sell_qty = math.floor(sell_qty * 1_000_000) / 1_000_000

        if sell_qty <= 0:
            logger.warning(
                "Saldo livre de %s é zero (ou zerou após arredondamento de precisão) no "
                "fechamento a mercado de %s - nada a vender.",
                base_asset, spot_symbol,
            )
            return 0.0, reference_price

        # Sem try/except aqui de propósito: se a ordem for REJEITADA pela
        # MEXC (ex: erro de validação), a exceção sobe para _execute_exit_live,
        # que deve tratar isso como uma falha real (pausar o par).
        order = await self.spot_client.new_order_market_by_qty(spot_symbol, "SELL", sell_qty)

        # A resposta imediata do POST pode não refletir o preenchimento real
        # ainda (executedQty=0 mesmo a ordem tendo sido aceita E preenchida
        # de verdade), especialmente em mercados menos líquidos - o mesmo
        # comportamento já visto e corrigido do lado da entrada. Antes de
        # declarar falha, confirma via polling do status real da ordem.
        filled_qty = float(order.get("executedQty", 0) or 0)
        quote_qty = float(order.get("cummulativeQuoteQty", 0) or 0)

        if filled_qty <= 0:
            order_id = order.get("orderId")
            fill = await self._wait_spot_fill(spot_symbol, order_id, timeout_s=8.0)
            if fill:
                filled_qty = fill["executed_qty"]
                quote_qty = fill["quote_qty"]

        if filled_qty <= 0:
            raise RuntimeError(
                f"Ordem de venda Spot em {spot_symbol} foi aceita mas o preenchimento não pôde ser "
                f"confirmado (nem na resposta imediata, nem consultando o status da ordem depois)."
            )
        fill_price = quote_qty / filled_qty if quote_qty > 0 else reference_price
        return filled_qty, fill_price

    def _clear_runtime_position(self, rt: PairRuntime, new_state: PairState = PairState.IDLE):
        """
        Limpa os campos de posição (entry_*) e define o novo estado.
        Por padrão volta para IDLE (uso normal de saída), mas o kill switch
        passa MANUAL_HALT explicitamente para não ser sobrescrito.
        """
        rt.state = new_state
        rt.entry_spread_pct = None
        rt.entry_spot_price = None
        rt.entry_futures_price = None
        rt.entry_spot_qty = None
        rt.entry_futures_vol = None
        rt.entry_notional_usdt = None
        rt.entry_ts = None
        rt.last_error = None

    # ---------------- Kill switch ----------------

    async def kill_switch(self):
        """
        Fecha imediatamente todas as posições abertas e move todos os pares
        para MANUAL_HALT. Em modo LIVE, fecha as duas pernas de cada posição
        A MERCADO (prioriza velocidade sobre preço - é uma parada de
        emergência) e cancela quaisquer ordens pendentes.
        """
        mode_label = "LIVE" if self.execution_mode == ExecutionMode.LIVE else "SIMULAÇÃO"
        logger.warning("[%s] KILL SWITCH acionado — fechando todas as posições e pausando o bot.", mode_label)

        async with self._lock:
            open_positions = [(s, rt) for s, rt in self.runtimes.items() if rt.state == PairState.OPEN]

        for symbol, rt in open_positions:
            if self.execution_mode == ExecutionMode.LIVE:
                futures_symbol = f"{symbol}_USDT"
                spot_symbol = f"{symbol}USDT"
                spec = self.contract_specs.get(symbol)

                try:
                    await self.futures_client.cancel_all_orders(futures_symbol)
                except Exception as e:
                    logger.warning("Kill switch: falha ao cancelar ordens abertas de Futures em %s: %s", symbol, e)
                try:
                    await self.spot_client.cancel_all_open_orders(spot_symbol)
                except Exception as e:
                    logger.warning("Kill switch: falha ao cancelar ordens abertas de Spot em %s: %s", symbol, e)

                await asyncio.gather(
                    self._close_futures_market(futures_symbol, rt.entry_futures_vol, rt.entry_futures_price, spec),
                    self._close_spot_market(spot_symbol, rt.entry_spot_qty, rt.entry_spot_price, symbol_display=symbol),
                    return_exceptions=True,
                )

            await self.storage.log_event(symbol, "kill_switch_close", {
                "entry_spread_pct": rt.entry_spread_pct,
            }, simulated=(self.execution_mode == ExecutionMode.SIMULATION))
            await self.storage.clear_position(symbol)

        async with self._lock:
            for rt in self.runtimes.values():
                self._clear_runtime_position(rt, new_state=PairState.MANUAL_HALT)
            for cfg in self.configs.values():
                cfg.enabled = False

        for symbol, cfg in self.configs.items():
            await self.storage.upsert_pair_config(
                symbol, False, cfg.entry_spread_pct, cfg.exit_spread_pct, cfg.position_size_usdt
            )

        await self._broadcast_snapshot()

    async def resume_from_halt(self, symbol: str):
        """
        Sai manualmente de MANUAL_HALT/PAUSED_ERROR de volta para IDLE.
        Também limpa quaisquer dados de posição residual (entry_spot_qty,
        etc.) mantidos para referência enquanto pausado - a expectativa é
        que você já tenha conferido manualmente na MEXC antes de retomar,
        então não faz sentido manter esses dados velhos "pendurados" no
        runtime depois disso. Não reabre posição nova sozinho.
        """
        symbol = self._normalize_symbol(symbol)
        rt = self.runtimes.get(symbol)
        if rt and rt.state in (PairState.MANUAL_HALT, PairState.PAUSED_ERROR):
            self._clear_runtime_position(rt, new_state=PairState.IDLE)
            await self.storage.clear_position(symbol)
            await self._broadcast_snapshot()

    # ---------------- Snapshot ----------------

    def get_snapshot(self) -> list:
        result = []
        for symbol, rt in self.runtimes.items():
            cfg = self.configs.get(symbol)
            d = rt.to_dict()
            d["config"] = {
                "enabled": cfg.enabled if cfg else False,
                "entry_spread_pct": cfg.entry_spread_pct if cfg else None,
                "exit_spread_pct": cfg.exit_spread_pct if cfg else None,
                "position_size_usdt": cfg.position_size_usdt if cfg else None,
            }
            d["execution_mode"] = self.execution_mode.value
            d["connection_degraded"] = self.connection_degraded
            result.append(d)
        return result
