import asyncio
import logging
import os
from contextlib import asynccontextmanager

import httpx
from dotenv import load_dotenv
from fastapi import FastAPI, WebSocket, WebSocketDisconnect, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel

from engine import ArbitrageEngine
from storage import Storage
from bot.bot_storage import BotStorage
from bot.bot_engine import ArbitrageBotEngine, ExecutionMode
from bot.mexc_spot_client import MexcSpotClient
from bot.mexc_futures_client import MexcFuturesClient
from bot.sizing import ContractSpec, SpotSymbolSpec
from bot.log_buffer import install_in_memory_log_handler

load_dotenv()

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(name)s] %(levelname)s %(message)s")
logger = logging.getLogger("main")

_log_buffer = install_in_memory_log_handler()

# ---------------------------------------------------------------------------
# TRAVA DE SEGURANÇA: o modo LIVE só é possível com a variável de ambiente
# MEXC_BOT_LIVE_MODE=true explicitamente definida no .env. Isso é proposital -
# é um passo manual extra, separado de qualquer toggle da interface, para que
# ativar execução real exija uma ação deliberada de edição de arquivo, não um
# clique acidental num botão.
# ---------------------------------------------------------------------------
LIVE_MODE_ENABLED = os.getenv("MEXC_BOT_LIVE_MODE", "false").strip().lower() == "true"
MAX_TOTAL_EXPOSURE_USDT = float(os.getenv("MEXC_BOT_MAX_TOTAL_EXPOSURE_USDT", "500"))

storage = Storage()
bot_storage = BotStorage()

_bot_http_client = httpx.AsyncClient()

_spot_key = os.getenv("MEXC_SPOT_API_KEY", "")
_spot_secret = os.getenv("MEXC_SPOT_SECRET_KEY", "")
_fut_key = os.getenv("MEXC_FUTURES_API_KEY", "")
_fut_secret = os.getenv("MEXC_FUTURES_SECRET_KEY", "")
_has_credentials = all([_spot_key, _spot_secret, _fut_key, _fut_secret])

# Clientes de CONSULTA (saldo, posições) - disponíveis sempre que houver
# credenciais no .env, independente do modo de execução (SIMULATION ou LIVE).
# São os mesmos clientes usados para enviar ordens, mas em modo SIMULATION o
# bot_engine nunca invoca métodos de ordem neles - só os endpoints de saldo
# abaixo (bot_balance) os utilizam nesse modo.
_query_spot_client = None
_query_futures_client = None
if _has_credentials:
    _query_spot_client = MexcSpotClient(_spot_key, _spot_secret, _bot_http_client)
    _query_futures_client = MexcFuturesClient(_fut_key, _fut_secret, _bot_http_client)
else:
    logger.info("Credenciais da MEXC não configuradas no .env - saldo Spot/Futures não estará disponível no dashboard.")

# Clientes de EXECUÇÃO (enviar ordens reais) - só existem em modo LIVE.
_spot_client = None
_futures_client = None
_execution_mode = ExecutionMode.SIMULATION

if LIVE_MODE_ENABLED:
    if not _has_credentials:
        logger.critical(
            "MEXC_BOT_LIVE_MODE=true mas as credenciais no .env estão incompletas. "
            "Iniciando em modo SIMULAÇÃO por segurança até isso ser corrigido."
        )
    else:
        _spot_client = _query_spot_client
        _futures_client = _query_futures_client
        _execution_mode = ExecutionMode.LIVE
        logger.warning(
            "=" * 70 + "\n"
            "MODO LIVE ATIVADO. O bot enviará ordens REAIS na sua conta MEXC.\n"
            "Teto de exposição global: %.2f USDT.\n" + "=" * 70,
            MAX_TOTAL_EXPOSURE_USDT,
        )

bot_engine = ArbitrageBotEngine(
    bot_storage,
    execution_mode=_execution_mode,
    spot_client=_spot_client,
    futures_client=_futures_client,
    max_total_exposure_usdt=MAX_TOTAL_EXPOSURE_USDT,
)


async def _on_price_update_for_bot(
    symbol: str, spot_price: float, futures_price: float, spread_pct: float,
    prices_from_book: bool = True,
    exit_spread_pct: float | None = None,
    spot_bid: float | None = None, futures_ask: float | None = None,
):
    await bot_engine.on_price_update(
        symbol, spot_price, futures_price, spread_pct,
        prices_from_book=prices_from_book,
        exit_spread_pct=exit_spread_pct,
        spot_bid=spot_bid, futures_ask=futures_ask,
    )


engine = ArbitrageEngine(storage, on_price_update=_on_price_update_for_bot)


async def _load_contract_specs_for_configured_pairs():
    """
    Carrega os metadados de contrato Futures (contractSize, minVol) e de
    símbolo Spot (baseAssetPrecision) de cada par que o bot tem configurado.
    Necessário para calcular corretamente o volume de contratos e para
    arredondar a quantidade de venda no Spot (evita o erro "amount scale
    is invalid" da MEXC). Roda na inicialização e sempre que uma nova
    config de par é criada (ver endpoint bot_set_pair_config).
    """
    if _futures_client is None:
        return
    for symbol in list(bot_engine.configs.keys()):
        if symbol not in bot_engine.contract_specs:
            try:
                futures_symbol = f"{symbol}_USDT"
                resp = await _futures_client.get_contract_detail(futures_symbol)
                data = resp.get("data")
                if isinstance(data, list):
                    data = data[0] if data else None
                if data:
                    bot_engine.contract_specs[symbol] = ContractSpec.from_api_response(data)
                    logger.info("Metadados de contrato (futures) carregados para %s.", symbol)
            except Exception as e:
                logger.warning("Não foi possível carregar metadados de contrato para %s: %s", symbol, e)

        if symbol not in bot_engine.spot_specs and _query_spot_client is not None:
            try:
                spot_symbol = f"{symbol}USDT"
                resp = await _query_spot_client.get_exchange_info(spot_symbol)
                symbols_data = resp.get("symbols", [])
                if symbols_data:
                    bot_engine.spot_specs[symbol] = SpotSymbolSpec.from_exchange_info(symbols_data[0])
                    logger.info(
                        "Metadados de símbolo (spot) carregados para %s (precisão: %d casas).",
                        symbol, bot_engine.spot_specs[symbol].base_asset_precision,
                    )
                else:
                    logger.warning("Nenhum símbolo retornado por exchangeInfo para %s.", spot_symbol)
            except Exception as e:
                logger.warning("Não foi possível carregar metadados de símbolo spot para %s: %s", symbol, e)


async def _sync_futures_priority_symbols():
    """
    Marca os pares configurados no bot como "prioritários" no WebSocket de
    futures, fazendo com que recebam subscrição individual (`sub.ticker`):
    atualização a cada ~1s e, principalmente, com bid1/ask1 reais - o canal
    agregado (`sub.tickers`) não traz bid/ask e só atualiza a cada 2s.

    Isso importa porque a perna Futures da estratégia é sempre VENDA, então
    o preço relevante é o BID (o que se recebe ao vender), não o último
    negociado.
    """
    futures_symbols = [f"{sym}_USDT" for sym in bot_engine.configs.keys()]
    spot_symbols = [f"{sym}USDT" for sym in bot_engine.configs.keys()]

    if futures_symbols:
        await engine.futures_ws.set_priority_symbols(futures_symbols)
    if spot_symbols:
        await engine.spot_ws.set_priority_symbols(spot_symbols)

    await _sync_focus_mode()


async def _sync_focus_mode():
    """
    Ativa o modo foco quando houver ao menos um par LIGADO no bot.

    Com foco ativo, todo o processamento (polling REST, WebSockets) se
    concentra apenas nos pares que o bot está operando - os demais pares
    do Dashboard param de ser atualizados. É uma troca deliberada:
    responsividade máxima onde há dinheiro em jogo, em detrimento do
    monitoramento amplo.

    Assim que o último par é desligado, o modo foco sai automaticamente e
    o Dashboard volta a monitorar todos os pares.
    """
    enabled_symbols = [sym for sym, cfg in bot_engine.configs.items() if cfg.enabled]
    await engine.set_focus_mode(bool(enabled_symbols), enabled_symbols)


@asynccontextmanager
async def lifespan(app: FastAPI):
    await storage.connect()
    await bot_storage.connect()
    await bot_engine.load_configs()
    await _load_contract_specs_for_configured_pairs()
    await engine.start()
    await _sync_futures_priority_symbols()
    logger.info(
        "Backend iniciado (dashboard + bot em modo %s). Aguardando dados da MEXC...",
        bot_engine.execution_mode.value.upper(),
    )
    yield
    await engine.shutdown()
    await _bot_http_client.aclose()
    await storage.close()
    await bot_storage.close()


app = FastAPI(title="MEXC Spot x Futures Arbitrage Dashboard + Bot", lifespan=lifespan)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:5173", "http://127.0.0.1:5173"],
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.get("/api/health")
async def health():
    return {
        "status": "ok",
        "pairs_tracked": len(engine.pairs),
        "connection_status": engine.compute_connection_status(),
        "bot_execution_mode": bot_engine.execution_mode.value,
    }


@app.get("/api/pairs")
async def get_pairs():
    """Snapshot pontual via REST (útil para debug ou primeira carga sem WS)."""
    return engine.get_snapshot()


@app.get("/api/spread-history/{symbol}")
async def get_spread_history(symbol: str):
    history = await engine.get_spread_history(symbol.upper())
    return {"symbol": symbol.upper(), "history": history}


@app.delete("/api/spread-extremes")
async def clear_spread_extremes(symbol: str | None = None):
    """
    Reseta os extremos (mín/máx histórico) de spread. Sem `symbol`, reseta
    todos os pares.

    Útil para descartar recordes registrados a partir de preços
    não-executáveis (último negociado em vez do book) - a partir da
    correção que passou a exigir preços do book, os novos extremos
    refletem apenas oportunidades que eram de fato executáveis.
    """
    removed = await engine.clear_spread_extremes(symbol.upper() if symbol else None)
    return {"status": "ok", "removed": removed}


@app.websocket("/ws")
async def websocket_endpoint(websocket: WebSocket):
    await websocket.accept()
    queue = engine.subscribe()
    try:
        # Envia snapshot inicial imediatamente
        await websocket.send_json(engine.get_snapshot())

        async def sender():
            while True:
                event = await queue.get()
                await websocket.send_json(event)

        async def heartbeat():
            while True:
                await asyncio.sleep(5)
                await websocket.send_json({"type": "heartbeat", "connection_status": engine.compute_connection_status()})

        sender_task = asyncio.create_task(sender())
        heartbeat_task = asyncio.create_task(heartbeat())

        try:
            while True:
                # Mantém a conexão viva e escuta desconexão do cliente
                await websocket.receive_text()
        except WebSocketDisconnect:
            pass
        finally:
            sender_task.cancel()
            heartbeat_task.cancel()
    finally:
        engine.unsubscribe(queue)


# =====================================================================
# Endpoints do Bot de Arbitragem (modo SIMULATION ou LIVE, ver bot_engine.py)
# =====================================================================

class PairConfigRequest(BaseModel):
    enabled: bool
    entry_spread_pct: float
    exit_spread_pct: float
    position_size_usdt: float


# Cache simples em memória para o saldo - evita bater na MEXC a cada poll
# do frontend (o balanço não muda a cada segundo, um cache de alguns
# segundos é imperceptível para o usuário e reduz risco de rate limit).
_balance_cache = {"data": None, "ts": 0.0}
_BALANCE_CACHE_TTL = 8.0


@app.get("/api/bot/balance")
async def bot_balance():
    """
    Saldo real das contas Spot e Futures na MEXC. Disponível sempre que
    houver credenciais no .env, independente do modo de execução do bot
    (funciona em SIMULATION e em LIVE) - usa apenas endpoints de LEITURA,
    nunca envia ordens.
    """
    if not _has_credentials:
        return {
            "available": False,
            "reason": "Credenciais da MEXC não configuradas no .env (MEXC_SPOT_API_KEY, etc).",
        }

    now = asyncio.get_event_loop().time()
    if _balance_cache["data"] is not None and (now - _balance_cache["ts"]) < _BALANCE_CACHE_TTL:
        return _balance_cache["data"]

    result = {"available": True, "spot": None, "futures": None, "errors": []}

    try:
        spot_balance = await _query_spot_client.get_balance("USDT")
        result["spot"] = {"asset": "USDT", "free": spot_balance["free"], "locked": spot_balance["locked"]}
    except Exception as e:
        result["errors"].append(f"Spot: {e}")

    try:
        assets = await _query_futures_client.get_assets()
        if assets.get("success"):
            usdt_assets = [a for a in assets.get("data", []) if a.get("currency") == "USDT"]
            if usdt_assets:
                a = usdt_assets[0]
                result["futures"] = {
                    "asset": "USDT",
                    "available_balance": float(a.get("availableBalance", 0) or 0),
                    "position_margin": float(a.get("positionMargin", 0) or 0),
                    "equity": float(a.get("equity", 0) or 0),
                }
            else:
                result["futures"] = {"asset": "USDT", "available_balance": 0.0, "position_margin": 0.0, "equity": 0.0}
        else:
            result["errors"].append(f"Futures: resposta inesperada ({assets})")
    except Exception as e:
        result["errors"].append(f"Futures: {e}")

    _balance_cache["data"] = result
    _balance_cache["ts"] = now
    return result


@app.get("/api/bot/health")
async def bot_health():
    return {
        "execution_mode": bot_engine.execution_mode.value,
        "connection_degraded": bot_engine.connection_degraded,
        "pairs_configured": len(bot_engine.configs),
        "max_total_exposure_usdt": bot_engine.max_total_exposure_usdt,
        "current_total_exposure_usdt": bot_engine.get_current_total_exposure_usdt(),
        "focus_mode": engine._focus_mode,
        "focus_symbols": sorted(engine._focus_symbols),
    }


@app.get("/api/bot/pairs")
async def bot_get_pairs():
    return {"pairs": bot_engine.get_snapshot()}


@app.post("/api/bot/pairs/{symbol}")
async def bot_set_pair_config(symbol: str, body: PairConfigRequest):
    symbol = symbol.upper()
    try:
        await bot_engine.set_pair_config(
            symbol, body.enabled, body.entry_spread_pct, body.exit_spread_pct, body.position_size_usdt
        )
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    await _load_contract_specs_for_configured_pairs()
    await _sync_futures_priority_symbols()
    return {"status": "ok", "symbol": symbol}


@app.delete("/api/bot/pairs/{symbol}")
async def bot_remove_pair_config(symbol: str):
    symbol = symbol.upper()
    await bot_engine.remove_pair_config(symbol)
    await _sync_focus_mode()
    return {"status": "ok", "symbol": symbol}


@app.post("/api/bot/pairs/{symbol}/resume")
async def bot_resume_pair(symbol: str):
    symbol = symbol.upper()
    await bot_engine.resume_from_halt(symbol)
    return {"status": "ok", "symbol": symbol}


@app.post("/api/bot/kill-switch")
async def bot_kill_switch():
    """
    Fecha imediatamente todas as posições abertas e pausa todos os pares
    do bot. Em modo LIVE, fecha as pernas reais a mercado na MEXC. Ação
    irreversível de emergência.
    """
    await bot_engine.kill_switch()
    # Kill switch desliga todos os pares - sai do modo foco automaticamente
    await _sync_focus_mode()
    return {"status": "ok", "message": "Kill switch acionado. Todos os pares pausados."}


@app.get("/api/bot/events")
async def bot_get_events(symbol: str | None = None, limit: int = 200):
    events = await bot_storage.get_recent_events(symbol.upper() if symbol else None, limit)
    return {"events": events}


@app.delete("/api/bot/events")
async def bot_clear_events(symbol: str | None = None):
    """Apaga o histórico de eventos/operações. Sem `symbol`, apaga tudo. Ação irreversível."""
    removed = await bot_storage.clear_events(symbol.upper() if symbol else None)
    return {"status": "ok", "removed": removed}


@app.get("/api/bot/logs")
async def bot_get_logs(level: str | None = None, limit: int = 500):
    """
    Log técnico em tempo real do que o bot está fazendo internamente:
    conexões, decisões de entrada/saída, erros, reconexões, etc. Diferente
    de /api/bot/events (que é o histórico de operações/trades); isso aqui é
    o log bruto de execução, útil para depurar comportamento do bot.
    """
    return {"logs": _log_buffer.get_logs(level=level, limit=limit)}


@app.delete("/api/bot/logs")
async def bot_clear_logs():
    removed = _log_buffer.clear()
    return {"status": "ok", "removed": removed}


@app.websocket("/ws/bot")
async def bot_websocket_endpoint(websocket: WebSocket):
    await websocket.accept()
    queue = bot_engine.subscribe()
    try:
        await websocket.send_json({"type": "bot_snapshot", "pairs": bot_engine.get_snapshot()})

        async def sender():
            while True:
                event = await queue.get()
                await websocket.send_json(event)

        sender_task = asyncio.create_task(sender())
        try:
            while True:
                await websocket.receive_text()
        except WebSocketDisconnect:
            pass
        finally:
            sender_task.cancel()
    finally:
        bot_engine.unsubscribe(queue)


if __name__ == "__main__":
    import uvicorn
    uvicorn.run("main:app", host="0.0.0.0", port=8000, reload=False)

