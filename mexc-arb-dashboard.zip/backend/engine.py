"""
Motor central do dashboard de arbitragem.

Responsabilidades:
- Descobrir e manter o universo de pares (spot ∩ futures).
- Fazer polling REST do spot (rápido, poucos segundos) - fonte primária de preço spot.
- Consumir o WebSocket de futures (push.tickers) - fonte primária de preço futures.
- Fazer polling REST de funding rate (não vem no ws.tickers).
- Calcular spread % por par e registrar histórico/cruzamentos via Storage.
- Manter um snapshot em memória pronto para servir via WS próprio ao frontend.
- Fallback automático: se o WS de futures cair, cai para polling REST de futures também.
"""
import asyncio
import logging
import time
from typing import Optional

import httpx

from config import (
    FUTURES_REST_POLL_INTERVAL,
    REST_FALLBACK_POLL_INTERVAL,
    PAIR_DISCOVERY_INTERVAL,
    CROSSING_WINDOWS_REFRESH_INTERVAL,
    MEXC_SPOT_TRADE_URL,
    MEXC_FUTURES_TRADE_URL,
)
import mexc_rest
from mexc_ws_futures import FuturesWebSocketClient
from mexc_ws_spot import SpotBookTickerWebSocketClient
from storage import Storage

logger = logging.getLogger("engine")

SPOT_POLL_INTERVAL = 3  # segundos - spot via REST (rápido o suficiente para "tempo real" percebido)


class PairState:
    """Estado em memória de um par (display_symbol, ex: 'EWT')."""

    __slots__ = (
        "display_symbol", "spot_symbol", "futures_symbol",
        "spot_price", "futures_price", "spot_vol", "futures_vol",
        "spot_bid", "spot_ask", "futures_bid", "futures_ask",
        "funding_rate", "spread_pct", "exit_spread_pct", "crossings_count",
        "crossings_1h", "crossings_12h", "crossings_24h",
        "last_crossing_ts", "last_update_ts",
        "min_spread_pct", "min_spread_ts", "max_spread_pct", "max_spread_ts",
        "min_exit_spread_pct", "min_exit_spread_ts",
        "max_exit_spread_pct", "max_exit_spread_ts",
    )

    def __init__(self, display_symbol: str, spot_symbol: str, futures_symbol: str):
        self.display_symbol = display_symbol
        self.spot_symbol = spot_symbol
        self.futures_symbol = futures_symbol
        self.spot_price: Optional[float] = None
        self.futures_price: Optional[float] = None
        # Book completo dos dois mercados - necessário porque entrada e saída
        # usam lados OPOSTOS do book (ver recompute_spread).
        self.spot_bid: Optional[float] = None
        self.spot_ask: Optional[float] = None
        self.futures_bid: Optional[float] = None
        self.futures_ask: Optional[float] = None
        self.spot_vol: float = 0.0
        self.futures_vol: float = 0.0
        self.funding_rate: float = 0.0
        self.spread_pct: Optional[float] = None
        self.exit_spread_pct: Optional[float] = None
        self.crossings_count: int = 0
        self.crossings_1h: int = 0
        self.crossings_12h: int = 0
        self.crossings_24h: int = 0
        self.last_crossing_ts: Optional[float] = None
        self.last_update_ts: float = 0.0
        self.min_spread_pct: Optional[float] = None
        self.min_spread_ts: Optional[float] = None
        self.max_spread_pct: Optional[float] = None
        self.max_spread_ts: Optional[float] = None
        # Extremos do spread de SAÍDA, rastreados separadamente porque é
        # uma grandeza diferente (lados opostos do book).
        self.min_exit_spread_pct: Optional[float] = None
        self.min_exit_spread_ts: Optional[float] = None
        self.max_exit_spread_pct: Optional[float] = None
        self.max_exit_spread_ts: Optional[float] = None

    def recompute_spread(self):
        """
        Calcula DOIS spreads distintos, porque entrada e saída executam em
        lados OPOSTOS do book:

        ENTRADA (spread_pct): compra Spot + vende Futures
            = (futures_BID - spot_ASK) / spot_ASK
            Você paga o ask do spot e recebe o bid do futures.

        SAÍDA (exit_spread_pct): vende Spot + recompra Futures
            = (futures_ASK - spot_BID) / spot_BID
            Você recebe o bid do spot e paga o ask do futures.

        Usar a fórmula de entrada para decidir a saída (bug anterior) fazia
        o bot "ver" um spread muito menor do que o real ao sair - em pares
        com book largo a diferença passa de 2 pontos percentuais, o que
        gerava saídas em condições piores do que o bot achava, com prejuízo
        pequeno e sistemático.

        Se o book não estiver disponível, cai para os preços de referência
        (comportamento antigo) - melhor um número aproximado do que nenhum.
        """
        spot_ask = self.spot_ask or self.spot_price
        futures_bid = self.futures_bid or self.futures_price
        if spot_ask and futures_bid and spot_ask > 0:
            self.spread_pct = (futures_bid - spot_ask) / spot_ask * 100
        else:
            self.spread_pct = None

        # O spread de SAÍDA exige o book de verdade (spot_bid e futures_ask).
        # Sem eles, fica None em vez de cair para os preços de referência -
        # esse fallback antes produzia um número que PARECIA válido mas era
        # calculado com os preços do lado errado do book, levando o bot a
        # sair em condições muito piores do que enxergava.
        if self.spot_bid and self.futures_ask and self.spot_bid > 0:
            self.exit_spread_pct = (self.futures_ask - self.spot_bid) / self.spot_bid * 100
        else:
            self.exit_spread_pct = None

    def to_dict(self) -> dict:
        return {
            "symbol": self.display_symbol,
            "spot_price": self.spot_price,
            "futures_price": self.futures_price,
            "spot_vol": self.spot_vol,
            "futures_vol": self.futures_vol,
            "spread_pct": self.spread_pct,
            "exit_spread_pct": self.exit_spread_pct,
            "min_exit_spread_pct": self.min_exit_spread_pct,
            "min_exit_spread_ts": self.min_exit_spread_ts,
            "max_exit_spread_pct": self.max_exit_spread_pct,
            "max_exit_spread_ts": self.max_exit_spread_ts,
            "spot_bid": self.spot_bid,
            "spot_ask": self.spot_ask,
            "futures_bid": self.futures_bid,
            "futures_ask": self.futures_ask,
            "funding_rate": self.funding_rate,
            "crossings_count": self.crossings_count,
            "crossings_1h": self.crossings_1h,
            "crossings_12h": self.crossings_12h,
            "crossings_24h": self.crossings_24h,
            "last_crossing_ts": self.last_crossing_ts,
            "min_spread_pct": self.min_spread_pct,
            "min_spread_ts": self.min_spread_ts,
            "max_spread_pct": self.max_spread_pct,
            "max_spread_ts": self.max_spread_ts,
            "futures_link": MEXC_FUTURES_TRADE_URL.format(symbol=self.display_symbol),
            "spot_link": MEXC_SPOT_TRADE_URL.format(symbol=self.display_symbol),
            "last_update_ts": self.last_update_ts,
        }


class ArbitrageEngine:
    def __init__(self, storage: Storage, on_price_update=None):
        self.storage = storage
        self.pairs: dict[str, PairState] = {}
        self.http_client = httpx.AsyncClient()
        self.futures_ws = FuturesWebSocketClient(on_tickers_update=self._on_futures_ws_update)
        self.spot_ws = SpotBookTickerWebSocketClient(
            on_book_ticker_update=self._on_spot_ws_update,
            on_validation_status_change=self._on_spot_ws_validation_change,
        )
        self.connection_status = "connecting"  # online | offline | reconectando
        self._subscribers: list[asyncio.Queue] = []
        self._lock = asyncio.Lock()
        self._futures_ws_last_msg_ts = 0.0
        # Modo foco: quando o bot está ativo, o sistema processa apenas os
        # pares que ele opera, ignorando os demais. Reduz drasticamente a
        # carga de processamento e a latência dos pares que importam.
        self._focus_mode: bool = False
        self._focus_symbols: set[str] = set()
        # Fonte ATUAL do preço de cada símbolo de futures: "book" (bid real,
        # canal individual) ou "last" (último negociado, canal agregado).
        self._futures_price_source: dict[str, str] = {}
        # Se o preço Spot vindo do REST tinha o book preenchido (askPrice > 0)
        # ou caiu no fallback lastPrice. Complementa is_trusted() do WS.
        self._spot_rest_has_book: dict[str, bool] = {}
        # Callback opcional: async fn(symbol, spot_price, futures_price, spread_pct).
        # Usado pelo bot de arbitragem (bot/bot_engine.py) para reagir aos mesmos
        # preços que já alimentam o dashboard, sem o dashboard depender do bot.
        self.on_price_update = on_price_update

    # ---------------- Pub/Sub para o WS do frontend ----------------

    def subscribe(self) -> asyncio.Queue:
        q = asyncio.Queue(maxsize=100)
        self._subscribers.append(q)
        return q

    def unsubscribe(self, q: asyncio.Queue):
        if q in self._subscribers:
            self._subscribers.remove(q)

    async def _broadcast(self, event: dict):
        for q in list(self._subscribers):
            try:
                q.put_nowait(event)
            except asyncio.QueueFull:
                pass  # cliente lento, descarta - próximo snapshot corrige

    # ---------------- Modo foco (bot ativo) ----------------

    async def set_focus_mode(self, enabled: bool, symbols: list[str] | None = None):
        """
        Ativa/desativa o modo foco. Quando ativo, o engine processa apenas
        os pares informados (tipicamente os configurados no bot), ignorando
        todos os outros.

        Efeitos:
        - Loops de polling REST percorrem só os pares em foco (em vez de
          centenas), reduzindo o tempo de ciclo praticamente a zero.
        - WS de spot subscreve apenas esses pares.
        - WS de futures pula o canal agregado, usando só os canais
          individuais (1s, com bid/ask).

        O Dashboard passa a mostrar dados atualizados somente dos pares em
        foco - os demais congelam no último valor conhecido. É uma troca
        deliberada: máxima responsividade onde há dinheiro em jogo.
        """
        self._focus_mode = enabled
        self._focus_symbols = set(symbols or [])

        await self.spot_ws.set_focus_mode(enabled)
        await self.futures_ws.set_focus_mode(enabled)

        if enabled:
            logger.warning(
                "MODO FOCO ATIVADO: processando apenas %d pares (%s). "
                "Os demais pares do Dashboard não serão atualizados.",
                len(self._focus_symbols), ", ".join(sorted(self._focus_symbols)) or "nenhum",
            )
        else:
            logger.info("Modo foco desativado: voltando a processar todos os pares.")

        await self._broadcast_snapshot()

    def _iter_active_pairs(self):
        """
        Itera os pares que devem ser processados agora. Em modo foco,
        retorna apenas os pares do bot; caso contrário, todos.
        """
        if not self._focus_mode:
            return list(self.pairs.values())
        return [s for s in self.pairs.values() if s.display_symbol in self._focus_symbols]

    # ---------------- Descoberta de pares ----------------

    async def discover_pairs(self):
        try:
            spot_tickers = await mexc_rest.fetch_spot_tickers(self.http_client)
            futures_tickers = await mexc_rest.fetch_futures_tickers(self.http_client)
        except Exception as e:
            logger.error("Erro ao descobrir pares: %s", e)
            return

        universe = mexc_rest.build_pair_universe(spot_tickers, futures_tickers)
        logger.info("Universo de pares descoberto: %d pares", len(universe))

        crossings = await self.storage.get_all_crossings()
        extremes = await self.storage.get_all_spread_extremes()
        exit_extremes = await self.storage.get_all_spread_extremes(table="exit_spread_extremes")

        async with self._lock:
            for display, syms in universe.items():
                if display not in self.pairs:
                    state = PairState(display, syms["spot_symbol"], syms["futures_symbol"])
                    saved = crossings.get(syms["futures_symbol"]) or crossings.get(display)
                    if saved:
                        state.crossings_count = saved["count"]
                        state.last_crossing_ts = saved["last_crossing_ts"]
                    saved_extremes = extremes.get(syms["futures_symbol"])
                    if saved_extremes:
                        state.min_spread_pct = saved_extremes["min_spread_pct"]
                        state.min_spread_ts = saved_extremes["min_spread_ts"]
                        state.max_spread_pct = saved_extremes["max_spread_pct"]
                        state.max_spread_ts = saved_extremes["max_spread_ts"]
                    saved_exit = exit_extremes.get(syms["futures_symbol"])
                    if saved_exit:
                        state.min_exit_spread_pct = saved_exit["min_spread_pct"]
                        state.min_exit_spread_ts = saved_exit["min_spread_ts"]
                        state.max_exit_spread_pct = saved_exit["max_spread_pct"]
                        state.max_exit_spread_ts = saved_exit["max_spread_ts"]
                    self.pairs[display] = state

            # Aplica ticker inicial já obtido
            for display, state in self.pairs.items():
                spot = spot_tickers.get(state.spot_symbol)
                fut = futures_tickers.get(state.futures_symbol)
                if spot:
                    state.spot_price = spot["price"]
                    state.spot_bid = spot.get("bid") or None
                    state.spot_ask = spot.get("ask") or None
                    state.spot_vol = spot["vol"]
                if fut:
                    state.futures_price = fut["price"]
                    state.futures_bid = fut.get("bid") or None
                    state.futures_ask = fut.get("ask") or None
                    state.futures_vol = fut["vol"]
                    state.funding_rate = fut["funding_rate"]
                state.recompute_spread()
                state.last_update_ts = time.time()

        # Registra os símbolos spot descobertos para o WS de bookTicker
        # subscrever (a subscrição de fato acontece na próxima
        # (re)conexão do WS, gerenciada pelo próprio cliente).
        spot_symbols = [state.spot_symbol for state in self.pairs.values()]
        await self.spot_ws.subscribe(spot_symbols)

    # ---------------- Loop: polling REST de spot ----------------

    async def spot_poll_loop(self):
        """
        Loop de polling REST do preço Spot. Continua rodando sempre,
        mesmo depois do WS de Spot ficar confiável para um símbolo -
        serve tanto de fallback (símbolos onde o WS ainda não validou ou
        perdeu a confiança) quanto de referência contínua de validação
        cruzada para o próprio WS (spot_ws.update_rest_reference).
        """
        while True:
            try:
                spot_tickers = await mexc_rest.fetch_spot_tickers(self.http_client)
                async with self._lock:
                    for state in self._iter_active_pairs():
                        data = spot_tickers.get(state.spot_symbol)
                        if not data:
                            continue

                        # Sempre alimenta a referência de validação do WS,
                        # independente de estar usando REST ou WS como fonte
                        # ativa no momento.
                        self.spot_ws.update_rest_reference(state.spot_symbol, data["price"])

                        # Só usa o preço REST para atualizar o estado se o WS
                        # ainda não for confiável para este símbolo - caso
                        # contrário, o preço já vem (mais rápido) via
                        # _on_spot_ws_update, e o REST aqui serve só de
                        # referência de validação, sem sobrescrever.
                        if not self.spot_ws.is_trusted(state.spot_symbol):
                            state.spot_price = data["price"]
                            state.spot_bid = data.get("bid") or None
                            state.spot_ask = data.get("ask") or None
                            state.spot_vol = data["vol"]
                            # Registra se veio do book (ask preenchido) ou se
                            # caiu no fallback lastPrice - o bot usa isso para
                            # recusar operar em cima de preço não-executável.
                            self._spot_rest_has_book[state.spot_symbol] = data.get("ask", 0) > 0
                            state.recompute_spread()
                            state.last_update_ts = time.time()
                            await self._register_and_maybe_crossing(state, defer_commit=True)
                        else:
                            # Ainda atualiza o volume (não vem do bookTicker)
                            state.spot_vol = data["vol"]
                await self.storage.commit()
                await self._broadcast_snapshot()
            except Exception as e:
                logger.warning("Erro no polling de spot: %s", e)
            await asyncio.sleep(SPOT_POLL_INTERVAL)

    # ---------------- Callback do WS de spot (bookTicker, quando confiável) ----------------

    async def _on_spot_ws_update(self, spot_symbol: str, bid: float, ask: float):
        """
        Chamado pelo SpotBookTickerWebSocketClient a cada atualização já
        validada contra REST. Usa o ASK (melhor preço de venda do book)
        como `spot_price` - é o preço que efetivamente se paga ao comprar
        a mercado, que é o que a perna Spot da estratégia sempre faz.
        Mesmo campo usado pelo REST (mexc_rest.fetch_spot_tickers).
        """
        async with self._lock:
            for state in self.pairs.values():
                if state.spot_symbol != spot_symbol:
                    continue
                state.spot_price = ask
                state.spot_bid = bid
                state.spot_ask = ask
                state.recompute_spread()
                state.last_update_ts = time.time()
                await self._register_and_maybe_crossing(state)
                break
        await self._broadcast_snapshot()

    async def _on_spot_ws_validation_change(self, spot_symbol: str, trusted: bool):
        status = "confiável (em uso)" if trusted else "não confiável (voltando para REST)"
        logger.info("WS de Spot para %s agora está: %s", spot_symbol, status)

    # ---------------- Loop: polling REST de funding rate ----------------

    async def futures_rest_poll_loop(self):
        """
        Polling REST periódico do ticker de futures.

        O endpoint REST de futures traz bid1/ask1 (preço de execução real)
        para TODOS os contratos, diferente do canal WebSocket agregado
        (`sub.tickers`), que só traz lastPrice. Como apenas os pares
        configurados no bot recebem subscrição WebSocket individual, este
        polling garante que os demais pares do Dashboard também tenham
        preço de execução - ainda que com atualização mais lenta.

        Também aproveita a mesma resposta para atualizar o funding rate,
        que não vem em nenhum canal WebSocket (evita uma segunda chamada
        REST só para isso).

        Não sobrescreve os pares que estão recebendo book via WebSocket
        individual: para esses, o dado do WS é mais recente.
        """
        while True:
            try:
                futures_tickers = await mexc_rest.fetch_futures_tickers(self.http_client)
                async with self._lock:
                    for state in self._iter_active_pairs():
                        data = futures_tickers.get(state.futures_symbol)
                        if not data:
                            continue

                        # Funding rate: sempre atualiza (só existe aqui)
                        state.funding_rate = data["funding_rate"]

                        # Preço: só atualiza se este par NÃO está recebendo
                        # book via WebSocket individual (que é mais rápido).
                        if self._futures_price_source.get(state.futures_symbol) == "book" and \
                           state.futures_symbol in self.futures_ws._priority_symbols:
                            continue

                        if data.get("bid", 0) > 0:
                            state.futures_price = data["price"]
                            state.futures_bid = data.get("bid") or None
                            state.futures_ask = data.get("ask") or None
                            state.futures_vol = data["vol"]
                            self._futures_price_source[state.futures_symbol] = "book"
                            state.recompute_spread()
                            state.last_update_ts = time.time()
                            await self._register_and_maybe_crossing(state, defer_commit=True)
                        else:
                            # O REST é a fonte mais completa (traz bid1 para
                            # todos os contratos). Se nem ele tem book para
                            # este par, o par realmente não tem book agora -
                            # marca como "last" para sair da tabela, em vez de
                            # manter um book velho indefinidamente.
                            state.futures_bid = None
                            state.futures_ask = None
                            state.futures_vol = data["vol"]
                            self._futures_price_source[state.futures_symbol] = "last"
                            state.recompute_spread()
                # Um único commit para todo o ciclo, em vez de um por par -
                # com centenas de pares, commits individuais dominavam o
                # tempo do ciclo (cada commit em SQLite força escrita em disco).
                await self.storage.commit()
                await self._broadcast_snapshot()
            except Exception as e:
                logger.warning("Erro no polling REST de futures: %s", e)
            await asyncio.sleep(FUTURES_REST_POLL_INTERVAL)

    # ---------------- Loop: re-descoberta periódica de pares novos ----------------

    async def pair_discovery_loop(self):
        while True:
            await asyncio.sleep(PAIR_DISCOVERY_INTERVAL)
            await self.discover_pairs()

    # ---------------- Loop: recálculo de cruzamentos por janela de tempo ----------------

    async def crossing_windows_loop(self):
        """
        Recalcula periodicamente quantos cruzamentos cada par teve nas
        últimas 1h / 12h / 24h. Roda em intervalo próprio (não a cada
        snapshot) para não sobrecarregar o SQLite com queries repetidas.
        """
        while True:
            try:
                now = time.time()
                counts_1h = await self.storage.get_crossing_counts_since(now - 3600)
                counts_12h = await self.storage.get_crossing_counts_since(now - 12 * 3600)
                counts_24h = await self.storage.get_crossing_counts_since(now - 24 * 3600)

                async with self._lock:
                    for state in self._iter_active_pairs():
                        key = state.futures_symbol
                        state.crossings_1h = counts_1h.get(key, 0)
                        state.crossings_12h = counts_12h.get(key, 0)
                        state.crossings_24h = counts_24h.get(key, 0)

                await self.storage.prune_crossing_events()
                await self._broadcast_snapshot()
            except Exception as e:
                logger.warning("Erro ao recalcular janelas de cruzamento: %s", e)
            await asyncio.sleep(CROSSING_WINDOWS_REFRESH_INTERVAL)

    # ---------------- Callback do WS de futures ----------------

    async def _on_futures_ws_update(self, tickers: dict):
        self._futures_ws_last_msg_ts = time.time()
        async with self._lock:
            for state in self._iter_active_pairs():
                data = tickers.get(state.futures_symbol)
                if not data:
                    continue

                has_book = bool(data.get("has_book"))

                if has_book:
                    # Canal individual (sub.ticker): traz bid/ask reais e é a
                    # fonte mais rápida (~1s). Sempre prevalece.
                    state.futures_price = data["price"]
                    state.futures_bid = data.get("bid") or None
                    state.futures_ask = data.get("ask") or None
                    state.futures_vol = data["vol"]
                    self._futures_price_source[state.futures_symbol] = "book"
                else:
                    # Canal agregado (sub.tickers): só tem lastPrice.
                    #
                    # NÃO pode destruir o book que o polling REST forneceu
                    # (o REST traz bid1/ask1 para todos os contratos). Antes,
                    # este bloco zerava futures_bid/ask e marcava a fonte como
                    # "last" a cada 2s, enquanto o REST restaurava a cada 5s -
                    # os dois ficavam se sobrescrevendo, fazendo os pares
                    # aparecerem e sumirem da tabela (575 -> 160 -> 355...).
                    #
                    # Aqui só atualizamos o volume e, se ainda não houver book
                    # algum para o par, o preço de referência.
                    state.futures_vol = data["vol"]
                    if not state.futures_bid:
                        state.futures_price = data["price"]
                        self._futures_price_source.setdefault(state.futures_symbol, "last")

                state.recompute_spread()
                state.last_update_ts = time.time()
                await self._register_and_maybe_crossing(state, defer_commit=True)
        await self.storage.commit()
        await self._broadcast_snapshot()

    # ---------------- Fallback REST caso WS de futures fique quieto ----------------

    async def futures_ws_fallback_loop(self):
        """Se o WS de futures não emitir nada por muito tempo, faz polling REST como fallback."""
        while True:
            await asyncio.sleep(REST_FALLBACK_POLL_INTERVAL)
            silent_for = time.time() - self._futures_ws_last_msg_ts
            if self._futures_ws_last_msg_ts == 0 or silent_for > 10:
                try:
                    futures_tickers = await mexc_rest.fetch_futures_tickers(self.http_client)
                    async with self._lock:
                        for state in self._iter_active_pairs():
                            data = futures_tickers.get(state.futures_symbol)
                            if not data:
                                continue
                            state.futures_price = data["price"]
                            state.futures_bid = data.get("bid") or None
                            state.futures_ask = data.get("ask") or None
                            state.futures_vol = data["vol"]
                            state.funding_rate = data["funding_rate"]
                            # O REST de futures TRAZ bid1/ask1, então este
                            # fallback fornece preço de execução real - marca
                            # como "book" quando o bid veio preenchido.
                            self._futures_price_source[state.futures_symbol] = (
                                "book" if data.get("bid", 0) > 0 else "last"
                            )
                            state.recompute_spread()
                            state.last_update_ts = time.time()
                            await self._register_and_maybe_crossing(state, defer_commit=True)
                    await self.storage.commit()
                    await self._broadcast_snapshot()
                except Exception as e:
                    logger.warning("Erro no fallback REST de futures: %s", e)

    # ---------------- Cruzamentos ----------------

    async def _register_and_maybe_crossing(self, state: PairState, defer_commit: bool = False):
        """
        Registra a amostra de spread, detecta cruzamentos e atualiza extremos.

        `defer_commit=True` evita um commit de banco por par - quem chama em
        loop sobre muitos pares deve usar isso e chamar `storage.commit()`
        uma única vez ao final. Com centenas de pares monitorados, um commit
        por par domina completamente o tempo do ciclo (cada commit em SQLite
        força escrita em disco).
        """
        if state.spread_pct is None:
            return

        # Os preços deste cálculo vieram do book (executáveis) ou são
        # "último negociado" (que em pares ilíquidos pode estar muito longe
        # do executável)? Usado tanto para decidir se vale registrar
        # extremos quanto para o bot decidir se pode operar.
        futures_from_book = self._futures_price_source.get(state.futures_symbol) == "book"
        spot_from_book = self.spot_ws.is_trusted(state.spot_symbol) or self._spot_rest_has_book.get(
            state.spot_symbol, False
        )
        prices_from_book = futures_from_book and spot_from_book

        # NADA é registrado sem preços do book. Cruzamentos, histórico de
        # spread (sparkline) e extremos calculados a partir de "último
        # negociado" são ficção: em pares sem book ativo, o preço pode estar
        # completamente descolado da realidade (chegando a ordens de grandeza
        # de diferença), gerando cruzamentos fantasma e recordes impossíveis.
        if not prices_from_book:
            return

        result = await self.storage.register_spread_sample(
            state.futures_symbol, state.spread_pct, defer_commit=defer_commit
        )
        state.crossings_count = result["count"]
        state.last_crossing_ts = result["last_crossing_ts"]

        extremes = await self.storage.update_spread_extremes(
            state.futures_symbol, state.spread_pct, defer_commit=defer_commit
        )
        state.min_spread_pct = extremes["min_spread_pct"]
        state.min_spread_ts = extremes["min_spread_ts"]
        state.max_spread_pct = extremes["max_spread_pct"]
        state.max_spread_ts = extremes["max_spread_ts"]

        # Extremos do spread de SAÍDA, rastreados na tabela própria.
        if state.exit_spread_pct is not None:
            exit_ext = await self.storage.update_spread_extremes(
                state.futures_symbol, state.exit_spread_pct,
                defer_commit=defer_commit, table="exit_spread_extremes",
            )
            state.min_exit_spread_pct = exit_ext["min_spread_pct"]
            state.min_exit_spread_ts = exit_ext["min_spread_ts"]
            state.max_exit_spread_pct = exit_ext["max_spread_pct"]
            state.max_exit_spread_ts = exit_ext["max_spread_ts"]

        if self.on_price_update is not None and state.spot_price and state.futures_price:
            try:
                await self.on_price_update(
                    state.display_symbol, state.spot_price, state.futures_price, state.spread_pct,
                    prices_from_book=prices_from_book,
                    exit_spread_pct=state.exit_spread_pct,
                    spot_bid=state.spot_bid, futures_ask=state.futures_ask,
                )
            except Exception as e:
                logger.warning("Erro no callback on_price_update (bot): %s", e)

    # ---------------- Status de conexão ----------------

    def compute_connection_status(self) -> str:
        if self.futures_ws.connected:
            return "online"
        silent_for = time.time() - self._futures_ws_last_msg_ts if self._futures_ws_last_msg_ts else 999
        if silent_for < 15:
            return "online"  # fallback REST está cobrindo bem
        return "reconectando"

    # ---------------- Snapshot / broadcast ----------------

    def get_snapshot(self) -> dict:
        """
        Monta o snapshot enviado ao Dashboard.

        Pares cujo preço de Futures NÃO vem do book (sem ⚡) são OMITIDOS:
        eles exibem o "último negociado", que em pares sem negociação recente
        pode estar completamente descolado da realidade - chegando a ordens
        de grandeza de diferença (ex: spot 0,27 e "futures" 97,92). Mostrar
        isso só polui a tela com spreads fictícios e atrapalha a leitura das
        oportunidades reais.
        """
        pairs_list = []
        hidden = 0
        for s in self.pairs.values():
            futures_source = self._futures_price_source.get(s.futures_symbol, "last")
            if futures_source != "book":
                hidden += 1
                continue
            d = s.to_dict()
            d["spot_price_source"] = "websocket" if self.spot_ws.is_trusted(s.spot_symbol) else "rest"
            d["futures_price_source"] = futures_source
            pairs_list.append(d)
        return {
            "type": "snapshot",
            "connection_status": self.compute_connection_status(),
            "pairs": pairs_list,
            "hidden_pairs_without_book": hidden,
            "server_time": time.time(),
        }

    async def _broadcast_snapshot(self):
        await self._broadcast(self.get_snapshot())

    async def clear_spread_extremes(self, display_symbol: str | None = None) -> int:
        """
        Reseta os extremos (mín/máx histórico) de spread, tanto no banco
        quanto no estado em memória (senão o valor antigo continuaria
        aparecendo na tela até o backend reiniciar).

        Sem `display_symbol`, reseta todos os pares.
        """
        if display_symbol:
            state = self.pairs.get(display_symbol)
            if state is None:
                return 0
            removed = await self.storage.clear_spread_extremes(state.futures_symbol)
            removed += await self.storage.clear_spread_extremes(
                state.futures_symbol, table="exit_spread_extremes"
            )
            async with self._lock:
                state.min_spread_pct = None
                state.min_spread_ts = None
                state.max_spread_pct = None
                state.max_spread_ts = None
                state.min_exit_spread_pct = None
                state.min_exit_spread_ts = None
                state.max_exit_spread_pct = None
                state.max_exit_spread_ts = None
        else:
            removed = await self.storage.clear_spread_extremes()
            removed += await self.storage.clear_spread_extremes(table="exit_spread_extremes")
            async with self._lock:
                for state in self.pairs.values():
                    state.min_spread_pct = None
                    state.min_spread_ts = None
                    state.max_spread_pct = None
                    state.max_spread_ts = None
                    state.min_exit_spread_pct = None
                    state.min_exit_spread_ts = None
                    state.max_exit_spread_pct = None
                    state.max_exit_spread_ts = None

        await self._broadcast_snapshot()
        return removed

    async def get_spread_history(self, display_symbol: str) -> list:
        state = self.pairs.get(display_symbol)
        if not state:
            return []
        return await self.storage.get_spread_history(state.futures_symbol)

    # ---------------- Lifecycle ----------------

    async def start(self):
        await self.discover_pairs()
        asyncio.create_task(self.futures_ws.run())
        asyncio.create_task(self.spot_ws.run())
        asyncio.create_task(self.spot_poll_loop())
        asyncio.create_task(self.futures_rest_poll_loop())
        asyncio.create_task(self.pair_discovery_loop())
        asyncio.create_task(self.futures_ws_fallback_loop())
        asyncio.create_task(self.crossing_windows_loop())

    async def shutdown(self):
        await self.futures_ws.stop()
        await self.spot_ws.stop()
        await self.http_client.aclose()
