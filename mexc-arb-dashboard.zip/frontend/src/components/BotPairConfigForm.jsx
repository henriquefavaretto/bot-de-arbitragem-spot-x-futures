import { useState } from 'react';

const API_BASE = '/api/bot';

export default function BotPairConfigForm({ onConfigured }) {
  const [symbol, setSymbol] = useState('');
  const [entrySpread, setEntrySpread] = useState('5');
  const [exitSpread, setExitSpread] = useState('1');
  const [positionSize, setPositionSize] = useState('100');
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState(null);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError(null);

    const cleanSymbol = symbol.trim().toUpperCase().replace(/USDT$/, '');
    if (!cleanSymbol) {
      setError('Informe o par (ex: EWTUSDT).');
      return;
    }

    const entryVal = parseFloat(entrySpread);
    const exitVal = parseFloat(exitSpread);
    const sizeVal = parseFloat(positionSize);

    if (isNaN(entryVal) || isNaN(exitVal) || isNaN(sizeVal)) {
      setError('Preencha todos os campos numéricos.');
      return;
    }

    setSubmitting(true);
    try {
      const resp = await fetch(`${API_BASE}/pairs/${cleanSymbol}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          enabled: true,
          entry_spread_pct: entryVal,
          exit_spread_pct: exitVal,
          position_size_usdt: sizeVal,
        }),
      });
      const data = await resp.json();
      if (!resp.ok) {
        setError(data.detail || 'Erro ao configurar o par.');
        return;
      }
      setSymbol('');
      onConfigured?.();
    } catch {
      setError('Não foi possível conectar ao backend. Ele está rodando?');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <form className="bot-config-form" onSubmit={handleSubmit}>
      <div className="bot-form-row">
        <label htmlFor="bot-symbol">Par (sem "USDT")</label>
        <input
          id="bot-symbol"
          type="text"
          placeholder="ex: EWT"
          value={symbol}
          onChange={(e) => setSymbol(e.target.value)}
          className="bot-form-input bot-symbol-input"
        />
      </div>
      <div className="bot-form-row">
        <label htmlFor="bot-entry">Entrada (spread % ≥)</label>
        <input
          id="bot-entry"
          type="number"
          step="0.1"
          value={entrySpread}
          onChange={(e) => setEntrySpread(e.target.value)}
          className="bot-form-input"
        />
      </div>
      <div className="bot-form-row">
        <label htmlFor="bot-exit">Saída (spread % ≤)</label>
        <input
          id="bot-exit"
          type="number"
          step="0.1"
          value={exitSpread}
          onChange={(e) => setExitSpread(e.target.value)}
          className="bot-form-input"
        />
      </div>
      <div className="bot-form-row">
        <label htmlFor="bot-size">Tamanho (USDT)</label>
        <input
          id="bot-size"
          type="number"
          step="10"
          value={positionSize}
          onChange={(e) => setPositionSize(e.target.value)}
          className="bot-form-input"
        />
      </div>
      <button type="submit" className="bot-submit-btn" disabled={submitting}>
        {submitting ? 'Salvando...' : '+ Adicionar / Atualizar par'}
      </button>
      {error && <div className="bot-form-error">{error}</div>}
    </form>
  );
}
